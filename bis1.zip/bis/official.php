<?php 
include 'content/head.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>

	<title>Officials</title>
</head>
<body>

<?php include 'sidenav.php'; ?> 
<?php include 'calendar.php'; ?>

<main>
	<div style="margin-left: 5px; margin-right: 5px; font-family:Droid Sans, 'Open Sans', sans-serif;" id="image_official">
	</div>
	<div class="row">
		<div id="update_text" class="modal modal-fixed-footer grey lighten-2">
			<div class="modal-content">
				<h4 class="center modal-title-update" style="font-family: century gothic">Update Content</h4>
				<div class="row">
					<div class="col s12">
						<form id="image_form_text" method="post" enctype="multipart/form-data">
							<div class="row">
								<input type="hidden" name="image_id" id="image_ids" />
								<div class="input-field col s6"><strong>Full Name</strong>
									<input id="f_name" name="f_name" type="text">
								</div>
								<div class="input-field col s6"><strong>Position</strong>
									<input id="pusit" name="pusit" type="text">
								</div>
							</div>

							<div class="row">	
								<div class="input-field col s12"><strong>Background</strong>
									<textarea id="b_ground" name="b_ground" class="materialize-textarea"></textarea>
								</div>
							</div>
							<div class="row">
								<input type="submit" name="update" id="update" value="Update" class="btn greenForlife darken-4" />
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>					
	</div>

	<div class="row">
		<div id="update_image" class="modal modal-fixed-footer grey lighten-2">
			<div class="modal-content">
				<h4 class="modal-title center black-text" style="font-family: century gothic">Update Image</h4>
				<div class="row">
					<div class="col s12">
						<form id="image_update_form" class="center" method="post" enctype="multipart/form-data">
							<div class="row">
								<p  class="center"><label>Select Image</label>
									<input type="file" name="imageX" id="imageX" />
								</p>
								<input type="hidden" name="action" id="action" value="update" />
								<input type="hidden" name="image_idX" id="image_idX" />
							</div>
							<div class="row">
								<input type="submit" name="" id="" value="Update" class="btn greenForlife darken-2" />
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>					
	</div>
</main>
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/materialize.min.js"></script>
<script src="js/init.js"></script>
<script src="js/initial.js"></script>
<script src="js/time.js"></script>
<script src="js/try.js"></script>
<script src="js/sweetalert.min.js"></script>
</body>
</html>