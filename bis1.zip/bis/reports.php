<?php include 'login/session.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Reports</title>
	<meta charset="UTF-8">
	<meta name="viewport"
	content="width=device-width, initial-scale=1.0">
	<link 
	rel="stylesheet" 
	type="text/css" 
	href="http://fonts.googleapis.com/icon?family=Material+Icons">
	<link 
	rel="stylesheet" 
	type="text/css" 
	href="../css/materialize.min.css"
	media="screen, projection">

	<link rel="stylesheet" href="css/css/fontawesome-all.min.css">
	<link rel="stylesheet" href="css/css/fontawesome.min.css">
	<link rel="stylesheet" href="css/material-design-iconic-font.min.css">
	<link rel="stylesheet" href="css/print.css" media="print">
</head>
<body class="grey lighten-4" id="page-reports">
	<a href="purokpage.php" class="btn blue no-print"><i class="zmdi zmdi-arrow-left"></i></a>
	<a class="btn green no-print" onclick="printReport()" style="padding:1px 15px;"><i class="fa fa-print" style="font-size:16px;"></i></a>
	<span class="white-text hide no-print" id="ala"><?php echo $_SESSION['assigned'];?></span>
	<div class="container">
		<div class="row" style="position: relative;">
			<div class="col s2 offset-s2">
				<img src="images/NEWCABALAN.png" width="100" height="100" style="position: absolute; top: 20px; left: 150px; margin-top: 2.5vh !important;">
			</div>
			<div class="col s6" id="p1">
				<h3 style="text-align: center; font-family: century gothic;">Brgy. New Cabalan</h3>
				<h5 style="text-align: center; font-family: century gothic;"> Olongapo City </h5>
				<p style="text-align: center; font-size: 13px;"><br>Tel No.(047) 224-2089/6969 Fax No. (047) 224-2089<br></p>
			</div>
		</div>
		<hr>
		<!--TABLE HERE!! -->

		<div class="row" id="report1">
			<table class="bordered" id="reports-header">
				<thead>
					<tr>
						<th>Last Name</th>
						<th>First Name</th>
						<th>Middle Name</th>
						<th>Gender</th>
						<th>Address</th>
						<th>Occupation</th>
					</tr>
				</thead>

				<tbody id="reportFetch">
					
				</tbody>
			</table>

		</div>
	</div>

	
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/materialize.min.js"></script>
	<script>
		printReport();
		$(".btn").addClass('hide');
		$(".btn").removeClass('hide');
		function printReport() {
			window.print();
		}

		var myUrl = "http://localhost";
		generate();
		function generate(){
			var s1 = document.getElementById('ala').innerHTML;
			$.ajax({
				url: myUrl + '/bis/include/reports.php?report=' + s1, 
				method:'GET',
				data:{report:s1},
				dataType : 'JSON',
				success:function (data){
					var body = "";
					for(var i = 0; i<data.length; i++){
						body += '<tr>';
						body += '<td class="left-align">'+data[i].r_lname+'</td>';
						body += '<td class="left-align">'+data[i].r_fname+'</td>';
						body += '<td class="left-align">'+data[i].r_mname+'</td>';
						body += '<td class="left-align">'+data[i].r_gender+'</td>';
						body += '<td class="left-align">'+data[i].r_address+'</td>';
						body += '<td class="left-align">'+data[i].r_occupation+'</td>';
						body += '</tr>';
						
					}
					

					console.log(data);
					$('#reportFetch').html(body);
				}
			});
		}
	</script>
</body>
</html>