<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Registration For Event Organizer</title>
  <meta name="viewport"
  content="width=device-width, initial-scale=1.0">
  <link 
  rel="stylesheet" 
  type="text/css" 
  href="http://fonts.googleapis.com/icon?family=Material+Icons">
  <link 
  rel="stylesheet" 
  type="text/css" 
  href="css/materialize.min.css"
  media="screen, projection">

  <!-- <link rel="icon" href="images/colorful socks.png"> -->
  <link rel="icon" href="images/gapo copy.png">
  <link rel="stylesheet" href="css/main1.css">
  <link rel="stylesheet" href="css/css/fontawesome-all.min.css">
  <link rel="stylesheet" href="css/css/fontawesome.min.css">
  <link rel="stylesheet" href="css/grabientcolors.css">
  <link rel="stylesheet" href="css/sweetalert.min.css">
  <link rel="stylesheet" href="css/material-design-iconic-font.min.css">
  <link rel="stylesheet" href="css/datepicker.css">
</head>
<body class="grey lighten-2">
  <nav class="main-nav white z-depth-0" style="font-family: Raleway;">
    <!-- <a class="brand-logo black-text" href="index1.html"><img src="images/NEWCABALAN.png" width="95" style="margin-left:200px"></a> -->

    <div class="nav-wrapper">
      <ul class="right hide-on-med-and-down">
        <li><a href="index1.html">Home</a></li>
        <!-- <li><a href="#news" class="tooltipped" data-tooltip="">News</a></li> -->

        <!-- Dropdown Trigger -->
        <li><a data-position="bottom" data-delay="350" href="eventorg.php">Register</a></li>
      </ul>
    </div>
  </nav>
  <br><br><br><br>
  <main>
    <div class="container">
      <div class="row">
        <div class="col s12 center">
          <h1>Registration Form</h1>
        </div>
      </div>
      <div class="row">
        <form id="register_form" method="post">
          <div class="row">
            <div class="input-field col s6">
              <input type="text" id="o_fname" placeholder="Firstname" name="o_fname" required="asdsa">
              <label for="o_fname">First Name</label>
            </div>
            <div class="input-field col s6">
              <input type="text" id="o_lname" placeholder="Lastname" name="o_lname" required="asda">
              <label for="o_lname">Last Name</label>
            </div>
          </div>
          <div class="row">
            <div class="input-field col s6">
              <input type="text" id="" placeholder="Event Type" name="e_type">
              <label for="e_type">Event Type</label>
            </div>
            <div class="input-field col s6">
              <input type="text" id="e_name" placeholder="Event Name" name="e_name">
              <label for="e_name">Event Name</label>
            </div>
          </div>
          <div class="row">
            <div class="input-field col s6">
              <input type="text" id="datepicker" name="e_date" class="datepicker" style="cursor: pointer;">
              <label for="e_date" class="active">Event Date</label>
            </div>
            <div class="input-field col s6">
              <input type="number" id="c_no" placeholder="Contact No." name="c_no" required="">
              <label for="c_no">Contact No.</label>
            </div>
          </div>
          <div class="row">
            <div class="col s12 center">
              <button class="btn-flat" name="submit" type="submit"> Register Event <i class="zmdi zmdi-mail-send"></i></button><hr>
            </div>
          </div>
        </form>
      </div>

    </div>
  </main>
  <div class="parallax-container">
    <br><br>
    <div class="row" style="padding: 100px 100px 100px 100px;">
      <div class="center grey lighten-2 z-depth-3 scrollspy" id="contact">
        <br>
        <a href="#top" class="black-text pulse accent-4" style="font-size: 30px;" ><i class="fa fa-angle-double-up"></i></a>
        <h4 class="black-text" style="font-family: century gothic;"><strong>Barangay New Cabalan</strong>
        </h4>
        <p class="black-text">Olongapo City, Zambales<br>Philippines, 2200</p>
        <ul>
          <li class="black-text"><i class="fa fa-phone-square"></i> (143) 143-1430</li>
          <li class="black-text"><i class="fa fa-envelope-square"></i> <a href="mailto:name@example.com" class="black-text" style="text-decoration: underline;">newcabalan@yahoo.com</a>
          </li>
        </ul>
        <br>
      </div>
    </div>
    <div class="parallax"><img src="images/kaka copy.jpg"></div>
  </div>
  <?php include 'footer/scripts.php'; ?>
  <script>
    setInterval(function(){
      $('.carousel').carousel('next');
    },3000);

    $(document).ready(function(){

        $('#register_form').submit(function(e){//Start of Adding of Residents
          var reg_form = $(this).serialize();
          // alert(reg_form);
          e.preventDefault();
          $.ajax({

            url:myUrl + '/bis/include/register.php',
            method:'POST',
            data: reg_form,
            dataType:'JSON',

            beforeSend: function() {
              Materialize.toast('Processing...', 1000);
            },
            success: function(data) {
              setTimeout(function () {
               Materialize.toast('Resident Successfully Added!', 2000);
               $('#register_form')[0].reset();
             },1000);
            }
          });
          });//end of 'Adding of residentss'

        $(function() {
          $('.datepicker').datepicker({
            minDate: 2 });
        });


      });




// $(function() {
  //   $( "#datepicker" ).datepicker({ dateFormat: "yy-mm-dd" });
  //   $("#datepicker").on("change",function(){
    //     var selected = $(this).val();
    //     var today = new Date();
    //     alert(selected);
    //   });
  // });
</script>
</body>
</html>