<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/jquery-ui.js"></script>
<script src="js/materialize.min.js"></script>
<script src="js/init.js"></script>
<script src="js/add.js"></script>
<script src="js/try.js"></script>
<script src="js/searchresident.js"></script>
<script src="js/time.js"></script>
<!-- <script src="js/datepicker.js"></script> -->
<script></script>
