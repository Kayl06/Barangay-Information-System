<?php include 'login/session.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <?php include 'content/head.php'; ?>
  <title>Admin Page</title>
</head>
<style> 
header, main, footer {
  padding-left: 300px;
}

@media only screen and (max-width : 992px) {
  header, main, footer {
    padding-left: 0;
  }
}
.side-nav ul li:hover{
  background-color: #eceff1;
}
.side-nav, ul{
  padding: 0;
  margin: 0;
  width: 270px;
  background-color: #FFFFFF;
  color: #FFFFFF;

}
.time {
 background-color: #0D7CA4;
}
.a, ul li i {
  color: black !important;
}
</style>
<body>

  <div class="container">
    <ul class="side-nav fixed" id="slide-out">
      <li>
        <div class="user-view">
          <div class="background center blue" style="  filter: brightness(80%);">
            <!-- <img src="./images/NEWCABALAN.png" alt=""> -->
          </div>
          <a href=""><img class="circle" src="images/businessman.png" alt=""></a>
          <a href=""><span class="white-text name"><?php echo $_SESSION['position']; echo ' '. $_SESSION['firstname']; ?></span></a>
          <a href=""><span class="white-text email">Purok <?php  echo $_SESSION['assigned'];?></span></a>
        </div>
      </li>

      <div class="a">
        <li><a href="purokpage.php" class="waves-effect">Residents<i style="font-size: 20px; color: darkgrey !important;" class="zmdi zmdi-male-female"></i></a></li>
        <li><div class="divider"></div></li>
        <span class="subheader">Account Settings <i style="font-size: 15px;" class="zmdi zmdi-settings"></i></span>
        
        <li><a id="logout" class="waves-effect" onclick="logout()">Logout <i style="font-size: 18px; color: #2a3744 !important;" class="zmdi zmdi-sign-in"></i></a></li>
      </div>
    </ul>
  </div>
  <a href="#" class="btn hide-on-large-only" data-activates="slide-out"><i class="zmdi zmdi-menu"></i></a>
  <script>

   function logout(){
    var x = confirm("Are you sure you want to log-out?");
    if (x == true) {
      console.log('success');
      swal("Signing Out...", "Successfully Log-out!!", "success");
      setTimeout(function(){
        window.location.href = 'http://localhost/bis/include/logout.php';
      }, 2000);
    }else{
      console.log('You Cancelled.');
    }
  }
</script>
</body>
</html>