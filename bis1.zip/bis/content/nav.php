<?php 
include 'login/session.php';
include 'head.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
</head>
<style>	
header, main, footer {
	padding-left: 304px;
}
.side-nav{
	padding: 0;
	margin: 0;
	width: 270px;
	background-color: #0D7CA4;
}
.time {

	background-color: #0D7CA4;
}

@media only screen and (max-width : 992px) {
	header, main, footer {
		padding-left: 0;
	}

}
/*
Color Palette
#E7E7E7
#B5B7B8
#06090F
#655656
#65938B
#B46B45
#0D7CA4
*/

</style>
<body>
	<div class="row">
		<div class="col s12">
			<div class="container" style="padding-left:12.2vh; font-family: century gothic;">
				<div class="row">
					<div class="time card-panel white-text col s4 left z-depth-3">
						<h5 class="col s12" id="calendar"></h5>	
						<h6 class="col s6" id="timepiece"></h6>
						<h6 class="col s1"><b class="day light" id="day"></b></h6>
					</div>
				</div>	
			</div>
			
		</div>
	</div>

	<div class="container">

		<ul class="side-nav fixed" style=" font-family:'Open Sans', sans-serif;">
			<li>
				<div class="row grey lighten-2 center">
					<div class="background center">
						<a href=""><img src="./images/NEWCABALAN.png"  style="height: 130px;" alt=""></a>
					</div>
					<span class="black-text name light" style="font-size: 25px; font-family: open sans;">Admin <?php echo $_SESSION['firstname']; ?></span></a>
				</div>
			</li>
			
			<li><a class="white-text waves-effect" href="adminpage.php">Dashboard<i style="font-size: 23px; color: darkgrey;" class="zmdi zmdi-chart"></i></a></li>
			<li><a class="white-text waves-effect" href="official.php"><i style="font-size: 25px; color: darkgrey;" class="zmdi zmdi-accounts-alt"></i>Officials</a></li>
			<li><a class="white-text waves-effect" href="addOfficial.php" style="margin-left: 20px;">
				<i style="font-size: 20px; color: darkgrey;" class="zmdi zmdi-account-add"></i>Add Officials</a>
			</li>
			<li><a class="white-text waves-effect" href="event.php"><i style="font-size: 23px; color: darkgrey;" class="zmdi zmdi-calendar-note"></i>Events</a></li>
			<li><a class="white-text waves-effect" href="project.php"><i style="font-size: 23px; color: darkgrey;" class="zmdi zmdi-city-alt"></i>Projects</a></li>
			<li><a class="white-text waves-effect" href="residents.php"><i style="font-size: 25px; color: darkgrey;" class="zmdi zmdi-male-female"></i>Residents</a></li>
			<li><a class="white-text waves-effect" id="logout" onclick="logout()"><i style="font-size: 24px; color: darkgrey;" class="zmdi zmdi-sign-in"></i>Logout</a></li>

		</ul>
	</div>


	<script src="./js/jquery-3.2.1.min.js"></script>
	<script src="./js/materialize.min.js"></script>
	<script>

		function logout(){
			var x = confirm("Are you sure you want to log-out?");
			if (x == true) {
				console.log('success');
				swal("Signing Out...", "Successfully Log-out!!", "success");
				setTimeout(function(){
					window.location.href = 'http://localhost/bis/include/logout.php';
				}, 2000);
			}else{
				console.log('You Cancelled.');
			}
		}
	</script>
</body>
</html>

