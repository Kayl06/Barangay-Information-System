<head>
	<meta charset="UTF-8">
	<meta name="viewport"
	content="width=device-width, initial-scale=1.0">
	<link 
	rel="stylesheet" 
	type="text/css" 
	href="http://fonts.googleapis.com/icon?family=Material+Icons">
	<link 
	rel="stylesheet" 
	type="text/css" 
	href="css/materialize.min.css"
	media="screen, projection">

	<link rel="icon" href="images/gapo copy.png">
	<link rel="stylesheet" href="css/main.css">
	<link rel="stylesheet" href="css/css/fontawesome-all.min.css">
	<link rel="stylesheet" href="css/css/fontawesome.min.css">
	<link rel="stylesheet" href="css/grabientcolors.css">
	<link rel="stylesheet" href="css/sweetalert.min.css">
	<link rel="stylesheet" href="css/material-design-iconic-font.min.css">

</head>