
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Admin</title>
	<?php include 'content/head.php'; ?>
	<link rel="stylesheet" href="css/print.css" media="print">
</head>
<style>
.tble {
	text-align: left;
	margin-left: 5% !important;
	max-width: 100%;
	height: 170px !important; overflow: auto !important;
}

.yes-print *{
	display: none;
}
#yes-print *{
	display: none;
}

</style>
<body class="#bdbdbd grey lighten-2">
	<div class="print">
		<?php include 'sidenav.php'; ?>
		<?php include 'calendar.php'; ?>
		<!-- <?php include 'content/nav.php'; ?> -->
	</div>
	<main>
		<div id="yes-print">
			<img src="images/NEWCABALAN.png" width="100" height="100" style="position:absolute;margin-top: 1vh !important;">
		</div>
		<div class="yes-print row" style="position: relative;">
			<div class="col s6" id="p1">
				<h3 style="text-align: center; font-family: century gothic;">Brgy. New Cabalan</h3>
				<h5 style="text-align: center; font-family: century gothic;"> Olongapo City </h5>
				<p style="text-align: center; font-size: 13px;"><br>Tel No.(047) 224-2089/6969 Fax No. (047) 224-2089<br></p>
			</div>
			<br><br>
		</div>
		<div class="row print">
			<div class="col s3 offset">
				<label> Purok </label>
				<select name="" id="greport" onchange="generate(this.value)">
					<option value="Generate">Generate</option>
					<option value="1">Purok 1</option>
					<option value="2">Purok 2</option>
					<option value="3">Purok 3</option>
					<option value="4">Purok 4</option>
					<option value="5">Purok 5</option>
					<option value="6">Purok 6</option>
				</select>
				<a class="print btn green hide" id="printer" onclick="adminPrintReport()" style="padding:1px 15px;"><i class="fa fa-print" style="font-size:16px;"></i></a>
			</div>
			
		</div>

		<div class="row print" id="chart">
			<div class="col s12">
				<canvas id="myChart" width="300" height="100"></canvas>
			</div>
		</div>

		<table class ="tables2 centered" id="report" >
			<tbody id="reportFetch">
				<!-- <button class="btn blue" onclick="printReport()"> Print Report </button> -->
			</tbody>
		</table>

	</main>
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/materialize.min.js"></script>
	<script src="js/init.js"></script>
	<script src="js/initial.js"></script>
	<script src="js/time.js"></script>
	<script src="js/form.js"></script>
	<script src="js/Chart.js"></script>
	<script src="js/populationChart.js"></script>
	<script src="js/sweetalert.min.js"></script>
	<script>
		// function printReport() {
		// 	window.print();
		// }
		var myUrl = "http://localhost";

		$(document).ready(function(){
			$('.btn').sideNav();
		});

		function generate(report){
			if (report == "Generate") {
				$('#chart').removeClass('hide').addClass('');
				$('#printer').addClass('hide');
				$('#report').addClass('hide');
			}else{
				$('#chart').addClass('hide');
				$('#report').removeClass('hide').addClass('');
				$('#printer').removeClass('hide').addClass('');


			// let ger = document.getElementById('greport').value; 
			// if (ger == '1') {
				$.ajax({
					url: myUrl + '/bis/include/reports.php?report=' + report, 
					method:'GET',
					data:{report:report},
					dataType : 'JSON',
					success:function (data){
						var body = "";

						body+= '<thead>';
						body+='<tr>';
						body+='<th class="center">Last Name</th>';
						body+='<th class="center">First Name</th>';
						body+='<th class="center">Middle Name</th>';
						body+='<th class="center">Gender</th>';
						body+='<th class="center">Address</th>';
						body+='<th class="center">Occupation</th>';
						body+='</tr>';
						body+='</thead>';
						for(var i = 0; i<data.length; i++){
							body += '<tr>';
							body += '<td class="left-align">'+data[i].r_lname+'</td>';
							body += '<td class="left-align">'+data[i].r_fname+'</td>';
							body += '<td class="left-align">'+data[i].r_mname+'</td>';
							body += '<td class="left-align">'+data[i].r_gender+'</td>';
							body += '<td class="left-align">'+data[i].r_address+'</td>';
							body += '<td class="left-align">'+data[i].r_occupation+'</td>';
							body += '</tr>';
						}

						console.log(data);
						$('#reportFetch').html(body);
					}
				});
			}
		}

		function adminPrintReport() {
			window.print();
		}
			// }

		</script>
	</body>
	</html>