<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Request Page</title>
	<?php include 'content/head.php'; ?>
</head>
<body  class="#bdbdbd grey lighten-2">
	<?php include 'sidenav.php';
	include 'calendar.php'; ?>

	<main>
		<table class="table bordered">
			<tr>
				<th>Full Name</th>
				<th>Event Type</th>
				<th>Event Name</th>
				<th>Event Date</th>
				<th>Contact No.</th>
				<th>Status</th>
				<th>Action</th>
			</tr>
			<tbody id="palabasin">
				
			</tbody>
			
		</table>
	</main>
	<?php include 'footer/scripts.php'; ?>

	<script>
		palabasin();
		var myUrl = "http://localhost";
		function palabasin (){
			$.ajax({
				url : myUrl + '/bis/include/showRequest.php',
				// method: 'GET',
				dataType: 'JSON',
				success: function(data){
					var body = "";
					for (var i = 0; i < data.length; i ++) {
						 // '';
						 body +='<tr>';
						 body +='<td>'+data[i].fname+' '+data[i].lname+'</td>';
						 body +='<td>'+data[i].etype+'</td>';
						 body +='<td>'+data[i].ename+'</td>';
						 body +='<td>'+data[i].edate+'</td>';
						 body +='<td>'+data[i].cnumber+'</td>';
						 body +='<td>'+data[i].status+'</td>';
						 body +='<td><a style="cursor:pointer" onclick="accept('+data[i].id+')"><i class="green-text zmdi zmdi-check" style="font-size: 21px;"></i></a> | <a style="cursor:pointer" onclick="decline('+data[i].id+')"><i class=" red-text zmdi zmdi-close" style="font-size: 21px;"></i></a> </td>';
						 body +='</tr>';
						}
						$('#palabasin').html(body);
					}
				});
		}

		function accept(id){
			var acceptID = id;
			$.ajax({
				url: myUrl+ '/bis/include/showRequest.php?acceptID=' + acceptID,
				method:'POST',
				data:{acceptID:acceptID},
				dataType: 'JSON',
				success: function (data) {
					Materialize.toast('Accepted!',3000);
					palabasin();
				}
			});
		}

		function decline(id){
			var decision = confirm("Do you want to delete this person?");
			if (decision == true){
				$.ajax({
					url: myUrl + '/bis/include/deleteRequest.php',
					method:'POST',
					data:{id:id},

					success: function(data) { 
						Materialize.toast('Resident Successfully Removed',1000);
						palabasin();
					}

				});
			}else{
				return false;
			}
		}
	</script>
</body>
</html>