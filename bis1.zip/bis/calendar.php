	<div class="row">
		<div class="col s12">
			<div class="container" style="padding-left:12.2vh; font-family: century gothic; ">
				<div class="row">
					<div class="time card-panel col s4 left z-depth-2" style="background-color: #F5F5F4; color: #000;">
						<h6 class="col s12" style="font-size: 30px !important;" id="timepiece"></h6>
						<h6 class="col s5" id="day"></h6>
						<h6 class="col s7" style="font-size: 15px;" id="calendar"></h6>
					</div>
				</div>	
			</div>
		</div>
	</div>