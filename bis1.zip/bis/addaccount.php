<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/materialize.min.css">
	<link rel="icon" href="images/gapo copy.png">
	<!-- <link rel="stylesheet" href="css/loginpage.css"> -->
	<link rel="stylesheet" href="css/sweetalert.min.css">
	<link rel="stylesheet" href="css/css/fontawesome-all.min.css">
	<link rel="stylesheet" href="css/css/fontawesome.min.css">
	<link rel="stylesheet" href="css/material-design-iconic-font.min.css">
	<link rel="stylesheet" href="css/grabientcolors.css">

	<title>Register Account</title>
</head>
<body class="grey lighten-4">
	<main>
		<div class="container">
			<div class="row">
				<div class="col s12 center"><a href="loginform.html" class="btn-flat blue-text"><i style="font-size: 15px;" class="zmdi zmdi-arrow-left"></i> Back</a></div>
				<h1 class="col s12 center" style="font-size: 50px; font-family: century gothic">Register Account</h1>
			</div>
			<div class="row">
				<div class="container">
					<div class="col s12">
						<form action="#!" id="register"> 
							<div class="row">
								<div class="input-field col s6">
									<input placeholder="First Name" required="" name="first_name" id="first_name" type="text" class="validate">
									<label for="first_name">First Name</label>
								</div>
								<div class="input-field col s6">
									<input placeholder="Last Name" id="last_name" name="last_name" type="text" class="validate">
									<label for="last_name">Last Name</label>
								</div>
							</div>

							<div class="row">
								<div class="input-field col s6">
									<input placeholder="Username" required="" name="username" id="username" type="text" class="validate">
									<label for="username">Username</label>
								</div>
								<div class="input-field col s6">
									<input placeholder="Password" name="password" id="password" type="password" class="validate">
									<label for="password">Password</label>
								</div>
							</div>

							<div class="row">
								<div class="input-field col s6">
									<input placeholder="Email" required="" name="email" id="email" type="email" class="validate">
									<label for="email">Email</label>
								</div>
								<div class="input-field col s4">
									<select name="accountType" onchange="changeds(this.value)" id="accountType">
										<option value="" disabled selected="">Choose</option>
										<option value="Admin">Staff Brgy.</option>
										<option value="Purok Leader">Purok Leader</option>
									</select>
									<label for="accountType">Account Type</label>
								</div>
								<div class="input-field col s2" id="parak">
									<select name="purokS" id="purokS">
										<option value="1">1</option>
										<option value="2">2</option>
										<option value="3">3</option>
										<option value="4">4</option>
										<option value="5">5</option>
										<option value="6">6</option>
									</select>
									<label for="purokS">Purok</label>
								</div>
								<div class="input-field col s2 hide" id="pes">
									<input required="" name="pes" id="pes" type="text" value="Brgy. Staff" disabled>
									<label for="pes">Position</label>
								</div>
							</div>

							<div class="row center">
								<div class="col s12">
									<button class="btn-flat blue-text center"  name="submit" style="margin-left: -30px; margin-top: 20px;">Register <i class="zmdi zmdi-mail-send"></i></button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</main>

	<script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
	<script type="text/javascript" src="js/materialize.min.js"></script>
	<!-- <script src="js/form.js"></script> -->
	<script src="js/sweetalert.min.js"></script>
	<script src="js/initial.js"></script>
	<script>
		var myUrl = "http://localhost/bis";
		$(document).ready(function () {

			$('#register').submit(function(e){
				var register_form = $(this).serialize();
				e.preventDefault();
				$.ajax({
					url: myUrl + '/login/register.php',
					method:'GET',
					data: register_form,
					dataType:'JSON',
					success: function(data){
						Materialize.toast('You are now registered...', 3000);
						setTimeout(function () {
							window.location.href ='http://localhost/bis/loginform.html';
						}, 3000);
					}
				});
			});

		});
		function changeds(palit){
			if (palit == "Admin") {
				$('#parak').addClass('hide');;
				$('#pes').removeClass('hide').addClass('');
			}else{
				$('#parak').removeClass('hide').addClass('');
				$('#pes').removeClass('hide').addClass('hide');
			}
		}

		// function refresh() {
		// 	$.ajax({
		// 		url: myUrl + '/login/countposition.php',
		// 		method:'GET',
		// 		dataType:'JSON',

		// 		success: function(datas){
		// 			for(var i = 0; i<datas.length; i++){
		// 				var body = "";
		// 				body += '<p id="lamans">'+datas[i].total_position+'</p>';
		// 			}
		// 			console.log(datas);
		// 		}

		// 	});
		// }

	</script>
</body>
</html>