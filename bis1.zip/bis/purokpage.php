<!DOCTYPE html>
<html lang="en">
<head>
	<title>Purok Page</title>
	<?php include 'content/head.php'; ?>
	<link rel="stylesheet" href="css/print.css" media="print">
</head>
<style>
.tble {
	font-size: 13.5px; margin-left: -14px !important;
	height: 170px !important; overflow: auto !important;
}
.yes-print *{
	display: none;
}
#yes-print *{
	display: none;
}
</style>
<body class="#bdbdbd grey lighten-2" id="page-reports">
	<div class="print">
		<?php include 'content/sidenavPurok.php'; ?>
		<?php include 'calendar.php'; ?>
	</div>
	<main>
		<div id="yes-print">
			<img src="images/NEWCABALAN.png" width="100" height="100" style="position:absolute;margin-top: 4vh !important;">
		</div>
		<div class="yes-print row" style="position: relative;">
			<div class="col s6" id="p1">
				<h3 style="text-align: center; font-family: century gothic;">Brgy. New Cabalan</h3>
				<h5 style="text-align: center; font-family: century gothic;"> Olongapo City </h5>
				<p style="text-align: center; font-size: 13px;"><br>Tel No.(047) 224-2089/6969 Fax No. (047) 224-2089<br></p>
				<span class="white-text hide" id="alas">Purok <?php echo $_SESSION['assigned'];?></span>
			</div>
		</div>
		<div class="row">
			
			<div class="print input-field col s3 right">
				<input class="grey lighten-2" id="search" type="search" onkeyup="searchResidents()" >
				<label class="search">Search</label>
			</div>

			<div class="reports-header row">
				<span class="print white-text hide" id="ala"><?php echo $_SESSION['assigned'];?></span>
				<table class="tble col s12 responsive-table z-depth-1" id="report">
					<thead class="white">
						<tr>
							<th class="center-align">Last Name</th>
							<th class="center-align">First Name</th>
							<th class="center-align">Middle Name</th>
							<th class="center-align">Gender</th>
							<th class="center-align">Address</th>
							<th class="center-align">Occupation</th>
							<th class="print center-align">Action</th>
						</tr>
					</thead>
					<tbody id="reportFetch" class="white"></tbody>
				</table>
				<div class="print">
					<a style="margin-left: -20px !important;" class="waves-effect btn blue modal-trigger" href="#addResident">
						<i class="zmdi zmdi-account-add" style="font-size: 22px;"></i>
					</a>
					<a class="btn green" href="reports.php" onload="printReport()" style="padding:1px 15px;"><i class="fa fa-print" style="font-size:16px;"></i></a>
				</div>
			</div>
		</div>
		<div class="print row">
			<div id="addResident" class="modal modal-fixed-footer grey lighten-2">
				<div class="modal-content">
					<div class="row">
						<div class="col s12">
							<form id="resident_form">
								<div class="row">
									<div class="row"><h4 class="light center" style="font-family: century gothic;">ADD RESIDENT</h4></div>
									<div class="input-field col s6">
										<input id="first_name" name="f_name" type="text" class="validate" required="">
										<label for="first_name">First Name</label>
									</div>
									<div class="input-field col s6">
										<input id="middle_name" name="m_name" type="text" class="validate" required="">
										<label for="middle_name">Middle Name</label>
									</div>
								</div>
								<div class="row">
									<div class="input-field col s6">
										<input id="last_name" type="text" name="l_name" class="validate" required="">
										<label for="last_name">Last Name</label>
									</div>
									<div class="input-field col s6">
										<select name="gender" id="r_gender">
											<option value="" disabled selected>Gender</option>
											<option value="M" name="male">Male</option>
											<option value="F" name="female">Female</option>
										</select>
									</div>
									<div class="row">
										<div class="input-field col s6">
											<input id="street" type="text" name="street" class="validate" required="">
											<label for="street">Street</label>
										</div>	
										<div class="input-field col s6">
											<input id="purok" type="text" name="purok" class="validate">
												<!-- <select name="purok" id="purok">
													<option value="" disabled selected>Purok</option>
													<option class="red" value="1" name="">1</option>
													<option class="red" value="2" name="">2</option>
													<option class="red" value="3" name="">3</option>
													<option class="red" value="4" name="">4</option>
													<option class="red" value="5" name="">5</option>
													<option class="red" value="6" name="">6</option>
												</select> -->
											</div>	

										</div>
										<div class="row">
											<div class="input-field col s6">
												<input id="barangay" type="text" name="barangay" class="validate"  value="New Cabalan"> 
												<label for="barangay">Barangay</label>
											</div>	

											<div class="input-field col s6">
												<input id="city" type="text" name="city" class="validate" value="Olongapo">
												<label for="city">City</label>
											</div>	
										</div>

										<div class="row">
											<div class="input-field col s6">
												<input id="occupation" type="text" name="occu" class="validate" required="">
												<label for="occupation">Occupation</label>
											</div>
											<div class="col s6" style="margin-top: 4vh;">
												<button class="btn waves-effect blueForlife">Add</button>
											</div>
										</div>
										<div>

										</div>
									</div>
								</form>
							</div>		
						</div>
					</div>
				</div>
			</div>

			<div class="print row">
				<div id="updateResident" name="updateResident" class="modal modal-fixed-footer">
					<div class="modal-content">
						<div class="row">
							<div class="col s12">
								<form id="update_form">
									<div class="row">
										<div class="row"><h4 class="light center" style="font-family: century gothic;">UDPATE FORM</h4></div>
									</div>
									<input id="r_id" type="hidden" class="validate" required="" value="">
									<div class="row">
										<div class="input-field col s6"><strong>First Name</strong>
											<input id="r_fname" type="text" class="validate" required="" value="">
										</div>
										<div class="input-field col s6"><strong>Middle Name</strong>
											<input id="r_mname" type="text" class="validate" required="" value="">
										</div>
									</div>
									<div class="row"> 
										<div class="input-field col s6"><strong>Last Name</strong>
											<input id="r_lname" type="text" class="validate" required="" value="">
										</div>
										<div class="input-field col s6"><strong>Gender</strong>
											<input id="r_gendere" type="text" class="validate" required="" value="">
										</div>
									</div>
									<div class="row">
										<div class="input-field col s6"><strong>Street</strong>
											<input id="r_street" type="text" name="street" class="validate" required="">

										</div>	
										<div class="input-field col s6"><strong>Purok</strong>
											<input id="r_purok" type="text" name="purok" class="validate" required="">

										</div>	

									</div>
									<div class="row">
										<div class="input-field col s6"><strong>Barangay</strong>
											<input disabled id="r_barangay" type="text" name="barangay" class="validate" required="" value="New Cabalan"> 
										</div>	

										<div class="input-field col s6" ><strong>City</strong>
											<input disabled  id="r_city" type="text" name="city" class="validate" required="" value="Olongapo">
										</div>	
									</div>

									<div class="row">
										<div class="input-field col s6"><strong>Occupation</strong>
											<input id="r_occupation" type="text" class="validate" required="" value="">
										</div>
										<div class="col s6" style="margin-top: 7vh;">
											<div class="col s6">
												<button class="btn waves-effect green accent-5 greenForlife">Update</button>
											</div>
										</div>
									</div>
								</form>
							</div>
						</div>		
					</div>
				</div>
			</div>

		</main>
		<script src="js/jquery-3.2.1.min.js"></script>
		<script src="js/materialize.min.js"></script>
		<script src="js/init.js"></script>
		<script src="js/initial.js"></script>
		<script src="js/time.js"></script>
		<script src="js/form.js"></script>
		<script src="js/purokAdd.js"></script>
		<script src="js/sweetalert.min.js"></script>
		<script>
			//var myUrl = "http://localhost";

		</script>
	</body>
	</html>