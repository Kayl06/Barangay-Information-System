s<?php 
include 'content/head.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Manage Projects</title>
	<style>
	.modal { margin-left: 30%; width: 50%; height: 80%; }
</style>
</head>
<body class="grey lighten-2">
	<?php include 'sidenav.php'; ?> 
	<?php include 'calendar.php'; ?>
	<main>
		<div class="row"><a style="margin-left: -15px; background-color: #0D7CA4;" class="waves-effect btn modal-trigger" href="#addProject" id="add"><i style="font-size: 20px; " class="zmdi zmdi-city-alt"></i></a></div>
		<div style="margin-left: 5px; margin-right: 5px; font-family:Droid Sans, 'Open Sans', sans-serif;" id="image_data_project"></div>
		<div class="container">
			<div class="row">
				<div id="addProject" class="modal modal-fixed-footer grey lighten-2">
					<div class="modal-content">
						<h4 class="modal-title center black-text" style="font-family: century gothic"></h4>
						<div class="row">
							<div class="col s12">
								<form id="image_form" method="post" enctype="multipart/form-data">
									<div class="row">
										<p id="paraG"><label>Select Image</label>
											<input type="file" name="image" id="image" />
										</p>
										<input type="hidden" name="action" id="action" value="insert" />
										<input type="hidden" name="image_id" id="image_id" />
										<div class="input-field col s6" id="ttle"><strong>Title</strong>
											<input id="title" name="title" type="text">
										</div>
									</div>
									<div class="row">
										<div class="input-field col s8" id="capsun"><strong>Caption</strong>
											<textarea id="caption" name="caption" class="materialize-textarea"></textarea>
										</div>
									</div>
									<div class="row">
										<div class="input-field col s12">
											<input type="submit" name="insert" id="insert" value="Insert" class="btn blueForlife"/>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>					
			</div>

			<div class="row">
				<div id="update_text" class="modal modal-fixed-footer grey lighten-2">
					<div class="modal-content">
						<h4 class="center modal-title-update" style="font-family: century gothic"></h4>
						<div class="row">
							<div class="col s12">
								<form id="form_text" method="post" enctype="multipart/form-data">
									<div class="row">
										<input type="hidden" name="action" id="action" value="insert" />
										<input type="hidden" name="image_id" id="image_ids" />
										<div class="input-field col s6"><strong>Title</strong>
											<input id="titless" name="title" type="text">
										</div>
										<div class="input-field col s12"><strong>Caption</strong>
											<textarea id="captionss" name="caption" class="materialize-textarea"></textarea>
										</div>
									</div>
									<div class="row">
										<input type="submit" name="update" id="update" value="Update" class="btn greenForlife darken-4" />
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>					
			</div>
		</div>

	</main>
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/materialize.min.js"></script>
	<script src="js/init.js"></script>
	<script src="js/initial.js"></script>
	<script src="js/time.js"></script>
	<script src="js/project.js"></script>
	<script src="js/sweetalert.min.js"></script>
	<!-- <script></script> -->
</body>
</html>