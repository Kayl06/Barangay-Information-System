<?php 
include 'content/head.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>

	<title>Manage Residents</title>

	<style>
	body{
		font-family: Open Sans;
	}
	.modal{
		margin-left: 30% !important; 
	}
	.tble {
		font-size: 13.5px; margin-left: -13px !important;
		height: 170px !important; overflow: auto !important;
	}
</style>
</head>
<body class="grey lighten-2">
	<?php include 'sidenav.php'; ?> 
	<?php include 'calendar.php'; ?>

	<main>

		<div class="row">
			<div class="input-field col s3 right">
				<input class="grey lighten-2" id="search1" type="search" onkeyup="searchResidents()" >
				<label class="search">Search</label>
			</div>

			<table class="tble col s12 responsive-table z-depth-1">
				<thead class="white">
					<tr>
						<th class="center-align">Last Name</th>
						<th class="center-align">First Name</th>
						<th class="center-align">Middle Name</th>
						<th class="center-align">Gender</th>
						<th class="center-align">Address</th>
						<th class="center-align">Occupation</th>
						<th class="center-align">Action</th>
					</tr>
				</thead>
				<tbody id="adminFetch" class="white"></tbody>
			</table>
			<br>
			<div class="row">
				<a style="margin-left: -20px !important;" class="waves-effect btn blue modal-trigger" href="#addResident">
					<i class="zmdi zmdi-account-add" style="font-size: 22px;"></i>
				</a>
			</div>
		</div>
		<div class="row">
			<div id="addResident" class="modal modal-fixed-footer grey lighten-2">
				<div class="modal-content">
					<div class="row">
						<div class="col s12">
							<form id="resident_form">
								<div class="row">
									<div class="row"><h4 class="light center" style="font-family: century gothic;">ADD RESIDENT</h4></div>
									<div class="input-field col s6">
										<input id="first_name" name="f_name" type="text" class="validate" required="">
										<label for="first_name">First Name</label>
									</div>
									<div class="input-field col s6">
										<input id="middle_name" name="m_name" type="text" class="validate" required="">
										<label for="middle_name">Middle Name</label>
									</div>
								</div>
								<div class="row">
									<div class="input-field col s6">
										<input id="last_name" type="text" name="l_name" class="validate" required="">
										<label for="last_name">Last Name</label>
									</div>
									<div class="input-field col s6">
										<select name="gender" id="r_gender">
											<option value="" disabled selected>Gender</option>
											<option value="M" name="male">Male</option>
											<option value="F" name="female">Female</option>
										</select>
									</div>
									<div class="row">
										<div class="input-field col s6">
											<input id="street" type="text" name="street" class="validate" required="">
											<label for="street">Street</label>
										</div>	
										<div class="input-field col s6">
											<!-- <input id="purok" type="text" name="purok" class="validate" required=""> -->
											<select name="purok" id="purok">
												<option value="" disabled selected>Purok</option>
												<option class="red" value="1" name="">1</option>
												<option class="red" value="2" name="">2</option>
												<option class="red" value="3" name="">3</option>
												<option class="red" value="4" name="">4</option>
												<option class="red" value="5" name="">5</option>
												<option class="red" value="6" name="">6</option>
											</select>
										</div>	

									</div>
									<div class="row">
										<div class="input-field col s6">
											<input id="barangay" type="text" name="barangay" class="validate" required="" value="New Cabalan"> 
											<label for="barangay">Barangay</label>
										</div>	

										<div class="input-field col s6">
											<input id="city" type="text" name="city" class="validate" required="" value="Olongapo">
											<label for="city">City</label>
										</div>	
									</div>

									<div class="row">
										<div class="input-field col s6">
											<input id="occupation" type="text" name="occu" class="validate" required="">
											<label for="occupation">Occupation</label>
										</div>
										<div class="col s6" style="margin-top: 4vh;">
											<button class="btn waves-effect blueForlife">Add</button>
										</div>
									</div>
									<div>

									</div>
								</div>
							</form>
						</div>		
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div id="updateResident" name="updateResident" class="modal modal-fixed-footer">
				<div class="modal-content">
					<div class="row">
						<div class="col s12">
							<form id="update_form">
								<div class="row">
									<div class="row"><h4 class="light center" style="font-family: century gothic;">UDPATE FORM</h4></div>
								</div>
								<input id="r_id" type="hidden" class="validate" required="" value="">
								<div class="row">
									<div class="input-field col s6"><strong>First Name</strong>
										<input id="r_fname" type="text" class="validate" required="" value="">
									</div>
									<div class="input-field col s6"><strong>Middle Name</strong>
										<input id="r_mname" type="text" class="validate" required="" value="">
									</div>
								</div>
								<div class="row"> 
									<div class="input-field col s6"><strong>Last Name</strong>
										<input id="r_lname" type="text" class="validate" required="" value="">
									</div>
									<div class="input-field col s6"><strong>Gender</strong>
										<input id="r_gendere" type="text" class="validate" required="" value="">
									</div>
								</div>
								<div class="row">
									<div class="input-field col s6"><strong>Street</strong>
										<input id="r_street" type="text" name="street" class="validate" required="">

									</div>	
									<div class="input-field col s6"><strong>Purok</strong>
										<input id="r_purok" type="text" name="purok" class="validate" required="">

									</div>	

								</div>
								<div class="row">
									<div class="input-field col s6"><strong>Barangay</strong>
										<input disabled id="r_barangay" type="text" name="barangay" class="validate" required="" value="New Cabalan"> 
									</div>	

									<div class="input-field col s6" ><strong>City</strong>
										<input disabled  id="r_city" type="text" name="city" class="validate" required="" value="Olongapo">
									</div>	
								</div>

								<div class="row">
									<div class="input-field col s6"><strong>Occupation</strong>
										<input id="r_occupation" type="text" class="validate" required="" value="">
									</div>
									<div class="col s6" style="margin-top: 7vh;">
										<div class="col s6">
											<button class="btn waves-effect green accent-5 greenForlife">Update</button>
										</div>
									</div>
								</div>
							</form>
						</div>
					</div>		
				</div>
			</div>
		</div>
	</div>
</main>


<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/materialize.min.js"></script>
<script src="js/init.js"></script>
<script src="js/initial.js"></script>
<script src="js/time.js"></script>
<script src="js/add.js"></script>
<script src="js/sweetalert.min.js"></script>
</body>
</html>

