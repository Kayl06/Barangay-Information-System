<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Request Page</title>
	<?php include 'content/head.php'; ?>
</head>
<body  class="#bdbdbd grey lighten-2">
	<?php include 'sidenav.php';
	include 'calendar.php'; ?>

	<main>
		<table class="table bordered">
			<tr>
				<th>Full Name</th>
				<th>Event Type</th>
				<th>Event Name</th>
				<th>Event Date</th>
				<th>Status</th>
			</tr>
			<tbody id="palabasin">
				
			</tbody>
			
		</table>
	</main>
	<?php include 'footer/scripts.php'; ?>

	<script>
		palabasin();

		var myUrl = "http://localhost";
		function palabasin (upcoming){
			var upcoming = show;
			$.ajax({
				url : myUrl + '/bis/include/showRequest.php',
				method: 'POST',
				data:{upcoming:upcoming},
				dataType: 'JSON',
				success: function(data){
					var body = "";
					for (var i = 0; i < data.length; i ++) {
						 // '';
						 body +='<tr>';
						 body +='<td>'+data[i].fname+' '+data[i].lname+'</td>';
						 body +='<td>'+data[i].etype+'</td>';
						 body +='<td>'+data[i].ename+'</td>';
						 body +='<td>'+data[i].edate+'</td>';
						 body +='<td>'+data[i].status+'</td>';
						 body +='</tr>';
						}
						$('#palabasin').html(body);
					}
				});
		}

	</script>
</body>
</html>