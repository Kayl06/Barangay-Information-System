<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
	<title>Login Page</title>
	<link rel="stylesheet" href="css/materialize.min.css">
	<link rel="icon" href="images/gapo copy.png">
	<link rel="stylesheet" href="css/loginpage.css">
	<link rel="stylesheet" href="css/sweetalert.min.css">
	<link rel="stylesheet" href="css/css/fontawesome-all.min.css">
	<link rel="stylesheet" href="css/css/fontawesome.min.css">
	<link rel="stylesheet" href="css/grabientcolors.css">
	<link rel="stylesheet" href="css/main.css">

</head>

<body style="font-family: Open Sans;">
	<main >
			<div class="container">				
				<!-- <div class="section"></div> -->
				<!-- <h4 class="white-text" style="font-family: Raleway;">Barangay Information System<br>Log-in</h4> -->
				<!-- <div class="section"></div> -->
				<div class="z-depth-1 grey lighten-4 row" style="display:inline-block; padding: 32px 48px 0px 48px; border: 1px solid #EEE;border-radius:20px;">

					<form class="col s12" id="login_form">
						<div class='row notice header5'  id="notice"></div>

						<div class='row'>
							<div class='input-field col s12'>
								<input class='validate' type="text" name='username' id='username' required="" />
								<label id="label1" for='username'>Enter your Username</label>
							</div>
						</div>

						<div class='row'>
							<div class='input-field col s12'>
								<input class='validate' type='password' name='password' id='password' />
								<label id="label2" for='password'>Enter your password</label>
							</div>
							<label style='float: right;'>
								<a class='blue-text light' href='#!'"><b>Forgot Password?</b></a>
							</label>
						</div>

						<br />
						<center>
							<div class='row'>
								<button id='btn_login' class='center col s12 btn btn-large waves-effect blueForlife' style="border-radius: 10px;"> Login
									<i style="font-size: 15px;" class="fa fa-sign-in-alt"></i> </button>
								</div>
							</center>
						</form>
					</div>
				</div>
		</main>



		<script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
		<script type="text/javascript" src="js/materialize.min.js"></script>
		<script src="js/form.js"></script>
		<script src="js/sweetalert.min.js"></script>
		<script>
		</script>
	</body>

	</html>