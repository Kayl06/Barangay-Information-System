<?php 
define("SERVER", "localhost");	
define("USERNAME", "root");	
define("DATABASE", "db_bis");	
define("PASSWORD", "");	

$con = mysqli_connect(SERVER, USERNAME, PASSWORD, DATABASE);

?>