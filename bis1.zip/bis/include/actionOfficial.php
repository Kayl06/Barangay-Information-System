<?php
require('connection.php');

if (isset($_POST['id'])) {
	$id = $_POST['id'];
	$sql=mysqli_query($con,"SELECT * FROM tbl_images WHERE id='$id'");

	while($rows = mysqli_fetch_array($sql)){
		$list[]= array(
			'caption' => $rows[2],
			'title' => $rows[3]
		);
	}
	echo json_encode($list);
}

if (isset($_POST['ids'])) {
	$id = $_POST['ids'];
	$sql=mysqli_query($con,"SELECT * FROM tbl_official WHERE id='$id'");

	while($rows = mysqli_fetch_array($sql)){
		$list[]= array(
			'full_name' => $rows[2],
			'position' => $rows[3],
			'bg_official' => $rows[4],
		);
	}
	echo json_encode($list);
}

if(isset($_POST['image_ids'])){
	$image_ids = $_POST['image_ids'];
	$full_name = $_POST['f_name'];
	$position = $_POST['pusit'];
	$b_ground = $_POST['b_ground'];

	$sql = "UPDATE tbl_official 
	SET full_name = '$full_name', position ='$position', bg_official='$b_ground'
	WHERE id = '$image_ids'";
	mysqli_query($con,$sql);

	echo json_encode(array('response' => 'successfully updated'));

}

if(isset($_POST['image_id']))
{
	$sql = "DELETE FROM tbl_official WHERE id = '".$_POST["image_id"]."'";
	mysqli_query($con, $sql);
}


if (isset($_POST['idP'])) 
{
	$id = $_POST['idP'];
	$sql=mysqli_query($con,"SELECT * FROM tbl_projects WHERE id='$id'");

	while($rows = mysqli_fetch_array($sql)){
		$list[]= array(
			'caption' => $rows[2],
			'title' => $rows[3]
		);
	}
	echo json_encode($list);
}




?>