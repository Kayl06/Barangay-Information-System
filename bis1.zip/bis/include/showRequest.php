<?php 
require_once('connection.php');



if (isset($_POST['acceptID'])) {
	$id = $_POST['acceptID'];
	$sql1 = "UPDATE event_register SET status = 'Accepted' WHERE id = '$id'";
	// $sql1 .= "INSERT INTO tbl_images ";
	$con->query($sql1);

	echo json_encode(array('response' => 'successfully updated'));

}

// else if($_POST['upcoming'] == "show") {
// 	$sql = "SELECT status FROM event_register ORDER BY id DESC";
// 	$result = $con->query($sql);

// 	while ($data = mysqli_fetch_assoc($result)) {
// 		// array_push($palabasin, $data);
// 		$list[]= array(
// 			'status' => $rows[7],
// 		);
// 	}

// 	echo json_encode($list);
// }	
else {

	$sql = "SELECT * FROM event_register ORDER BY id DESC";
	$result = $con->query($sql);

	$palabasin = array();
	while ($data = mysqli_fetch_assoc($result)) {
		array_push($palabasin, $data);
	}

	echo json_encode($palabasin);
}


// if (isset($_GET['Pending'])) {
// 	$code = mysqli_query($con,"SELECT * FROM event_register WHERE status = 'Pending' ORDER BY id DESC");
// 	$array = array();
// 	while($rowz = mysqli_fetch_assoc($code)){
// 		$array[] = $rowz;
// 	}
// 	echo json_encode($array);
// }

?>