<?php 
require_once('connection.php');

$id = $_POST['id'];
$sql = "DELETE FROM event_register WHERE id = '$id'";
$con->query($sql);

echo json_encode(array('response' => 'successfully deleted'));

?>