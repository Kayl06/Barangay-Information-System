<?php 
header('Access-Control-Origin:*');
header('Content-type:application-json');
?>

<?php 
require 'connection.php';

$r_id = $_POST['r_id'];
$r_lname = $_POST['r_lname'];
$r_fname = $_POST['r_fname'];
$r_mname = $_POST['r_mname'];
$r_gender = $_POST['r_gender'];
// $r_address = $_POST['r_address'];
$r_street = $_POST['r_street'];
$r_purok = $_POST['r_purok'];
$r_barangay = $_POST['r_barangay'];
$r_city = $_POST['r_city'];
$r_occupation = $_POST['r_occupation'];

$sql = "UPDATE tbl_residents 
		SET r_lname='$r_lname', 
			r_fname='$r_fname', 
			r_mname= '$r_mname',
			r_gender= '$r_gender', 
			r_address='$r_street St. Purok $r_purok $r_barangay $r_city', 
			r_street= '$r_street', 
			r_purok= '$r_purok', 
			r_occupation='$r_occupation' 
		WHERE id = '$r_id'";
$con->query($sql);

echo json_encode(array('response' => 'successfully updated'));

?>