<?php 
require_once('connection.php');


if ($_POST['action']) {
	
	if($_POST["action"] == "fetch")
	{
		$query = "SELECT * FROM tbl_projects ORDER BY id DESC";
		$result = mysqli_query($con, $query);
		$output = '
		<table class="table responsive-table bordered" style="font-size: 13.5px; margin-left: -20px !important;">  
		<tr>
		<th class="center">Image</th>
		<th class="center" width="30%">Title</th>
		<th class="center">Caption</th>
		<th class="center">Action</th>
		</tr>
		';
		while($row = mysqli_fetch_array($result))
		{
			$output .= '

			<tr>
			<td>
			<img src="data:image/jpeg;base64,'.base64_encode($row['name'] ).'" height="120" width="250">
			<button class="update btn grey lighten-2 black-text waves-effect left" name="update" id="'.$row["id"].'"><i class="fa fa-image"></i>
			</button>
			</td>
			<td><h6 class="center"><b>'.$row['title'].'</b></h6></td>
			<td><h6 class="justify">'.$row['caption'].'</h6></td>
			<td style="letter-spacing:.2rem;"><a name="update"  style="color:#3293EE;" class=" update_text" id="'.$row["id"].'"><i style="font-size: 15px; cursor:pointer;" class="fa fa-pencil-alt"></i></a> 
			<a name="delete" style="color:#9E0606" class=" delete" id="'.$row["id"].'"><i style="font-size: 15px; cursor:pointer;" class="fa fa-trash-alt"></i></a></td>
			</td>
			</tr>
			';
		}
		$output .= '</table>';

		echo $output;
	}
	if($_POST["action"] == "insert")
	{	
		$caption = $_POST["caption"];
		$title = $_POST["title"];

		$file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
		$query = "INSERT INTO tbl_projects(name, caption, title) VALUES ('$file','$caption', '$title')";
		mysqli_query($con, $query);
	}

	if($_POST["action"] == "delete")
	{
		$query = "DELETE FROM tbl_projects WHERE id = '".$_POST["image_id"]."'";
		mysqli_query($con, $query);
	}

	if($_POST["action"] == "update")
	{

		$file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
		$query = "UPDATE tbl_projects SET name = '$file' WHERE id = '".$_POST["image_id"]."'";
		mysqli_query($con,$query);
	}
}

if(isset($_POST['image_ids']))
{
	$image_ids = $_POST['image_ids'];
	$captions = $_POST['captions'];
	$titles = $_POST['titles'];

	$query = "UPDATE tbl_projects SET caption = '$captions', title ='$titles' WHERE id = '$image_ids'";
	mysqli_query($con,$query);

	echo json_encode(array('response' => 'successfully updated'));

}

?>