<?php 
require 'connection.php';

if(isset($_POST["action"]))
{

	if($_POST["action"] == "insert")
	{

		$fname = $_POST["fname"];
		$mname = $_POST["mname"];
		$lname = $_POST["lname"];
		$position = $_POST["position"];
		$bground = $_POST["bground"];

		$file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));
		$sql = "INSERT INTO tbl_official(name,full_name,position,bg_official) VALUES ('$file','$fname $mname. $lname','$position',
		'$bground')";
		mysqli_query($con, $sql);
	}

	if($_POST["action"] == "fetch")
	{
		$query = "SELECT * FROM tbl_official ORDER BY id ASC";
		$result = mysqli_query($con, $query);
		$output = '
		<table class="table responsive-table bordered centered" style="font-size: 13.5px; margin-left: -20px !important;">  
		<tr>
		<th class="center">Image</th>
		<th class="center" width="25%">Name</th>
		<th class="center" width="15%">Position</th>
		<th class="center" width="50%">Background</th>
		<th class="center" width="5%">Action</th>
		</tr>
		';
		while($row = mysqli_fetch_array($result))
		{
			$output .= '

			<tr>
			<td>
			<img class="circle" src="data:image/jpeg;base64,'.base64_encode($row['name'] ).'" height="170" widht="170"><br>
			<button class="update_pic btn-flat grey lighten-2 orange-text waves-effect left" name="update" id="'.$row["id"].'">
			<i class="fa fa-image"></i>
			</button>
			</td>
			<td><h6 class="center"><b>'.$row['full_name'].'</b></h6></td>
			<td><h6 class="center"><b>'.$row['position'].'</b></h6></td>
			<td><h6 class="justify">'.$row['bg_official'].'</h6></td>
			<td style="letter-spacing:.2rem;"><a name="update"  style="color:#3293EE;" class=" update_text" id="'.$row["id"].'"><i style="font-size: 15px; cursor:pointer;" class="fa fa-pencil-alt"></i></a> 
			<a name="delete" style="color:#9E0606" class=" delete" id="'.$row["id"].'"><i style="font-size: 15px; cursor:pointer;" class="fa fa-trash-alt"></i></a></td>
			</tr>
			';
		}
		$output .= '</table>';

		echo $output;
	}

	if($_POST["action"] == "update")
	{

		$file = addslashes(file_get_contents($_FILES["imageX"]["tmp_name"]));
		$query = "UPDATE tbl_official SET name = '$file' WHERE id = '".$_POST["image_idX"]."'";
		if (mysqli_query($con,$query) == true) {
			echo "s";
		}else
		{
			echo "error";
		}
	}

}
?>

