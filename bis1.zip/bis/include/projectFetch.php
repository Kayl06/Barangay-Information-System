<?php 
require 'connection.php';
$query = "SELECT * FROM tbl_projects ORDER BY id DESC";
$result = mysqli_query($con, $query);
$output = '';
while($row = mysqli_fetch_array($result))
{
	$output .= '
	<div class="col s3 m4">	
		<div class="card">
			<div class="card-image">
				<img height="200" class=" z-depth-3" src="data:image/jpeg;base64,'.base64_encode($row['name'] ).'" >
			</div>
		</div>
		<div class="card-content card-panel grey lighten-2 z-depth-3" style="height: 185px; overflow: auto;">
			<span class="card-title black-text center"><h5>'.$row['title'].'</h5></span>
			<span><h6>'.$row['caption'].'</h6></span>
		</div>
	</div>
	';
}

echo json_encode($output);

?>