<?php 
header('Allow-Acces-Origin:*');
header('Content-Type:application-json');
?>

<?php 
require('connection.php');

$sql = 'SELECT * FROM tbl_residents ORDER BY id ASC';
$res = $con->query($sql);//Query result

$residents = [];
while ($data = mysqli_fetch_assoc($res)) {
	array_push($residents, $data);
	// $residents[] = $data;
}
echo json_encode($residents);

?>