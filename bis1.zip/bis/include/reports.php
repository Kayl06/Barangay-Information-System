<?php 
header('Allow-Access-Origin:*');
header('Content-Type:application-json');
?>

<?php 
require_once 'connection.php';

if (isset($_GET['report'])) {
		# code...
	$purok = $_GET['report'];
	$sql = "SELECT * FROM tbl_residents WHERE r_purok = '$purok'";
	$res = $con->query($sql);

	$reports = [];
	while ($data = mysqli_fetch_assoc($res)) {
		array_push($reports, $data);
	}
	echo json_encode($reports);

}
?>

