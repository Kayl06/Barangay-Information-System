<?php
require_once('connection.php');

$search = $_GET['search'];

$sql = mysqli_query($con, "SELECT * FROM tbl_residents WHERE id LIKE '%$search%' OR r_lname LIKE '%$search%' OR r_fname LIKE '%$search%' OR r_mname LIKE 
	'%$search%' OR r_gender LIKE '%$search%' OR r_address LIKE '%$search%' OR r_occupation LIKE '%$search%' ");

$list = array();
while($rows = mysqli_fetch_array($sql)){
	$list[] = array(
		'id' => $rows[0],
		'r_lname' => $rows[1],
		'r_fname' => $rows[2],
		'r_mname' => $rows[3],
		'r_gender' => $rows[4],
		'r_address' => $rows[5],
		'r_occupation' => $rows[10]
	);
}

echo json_encode($list);


?>

