<?php 
header('Allow-Access-Origin:*');
header('Content-Type:application-json');
?>

<?php 
session_start();

require 'connection.php';

$l_name = $_POST['l_name'];
$f_name = $_POST['f_name'];
$m_name = $_POST['m_name'];
$gender = $_POST['gender'];
	// $address = $_POST['address'];
$street = $_POST['street'];
$purok = $_POST['purok'];
$barangay = $_POST['barangay'];
$city = $_POST['city'];
$occu = $_POST['occu'];

if ($gender == "M") {
	$gender = "Male";
}else{
	$gender = "Female";
}

$sql = "INSERT INTO tbl_residents(r_lname,r_fname,r_mname,r_gender, r_address, r_street,r_purok,
		r_barangay,r_city, r_occupation) 
		VALUES('$l_name', '$f_name', '$m_name','$gender','$street St. Purok $purok $barangay $city City', 
		'$street', '$purok', '$barangay','$city', '$occu')";

$con->query($sql);

echo json_encode(array('response' => 'successfully inserted'));

?>