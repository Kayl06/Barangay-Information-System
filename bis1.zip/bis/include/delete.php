<?php 
header('Allow-Access-Control:*');
header('Content-type:application-json');
?>

<?php 
require 'connection.php';

$id = $_POST['id'];

$sql = "DELETE FROM tbl_residents WHERE id='$id'";
$con->query($sql);

echo json_encode(array('response' => 'successfully deleted'));

?>