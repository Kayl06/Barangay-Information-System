<?php 
header('Access-Control-Origin:*');
header('Content-type:application-json');
?>
<?php 
require_once('connection.php');

$fname = $_POST['o_fname'];
$lname = $_POST['o_lname'];
$etype = $_POST['e_type'];
$ename = $_POST['e_name'];
$edate = $_POST['e_date'];
$cno = $_POST['c_no'];

$sql = "INSERT INTO event_register (fname , lname, etype, ename, edate, cnumber, status) 
VALUES('$fname','$lname','$etype', '$ename', '$edate', '$cno', 'Pending')";
$con->query($sql);

echo json_encode(array('response' => 'successfully inserted'));

?>