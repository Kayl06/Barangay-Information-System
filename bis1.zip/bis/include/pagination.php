<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title></title>

</head>
<style>

.btn {
	display: inline-block;
	padding: 10px;
	border-radius: 5px; /*optional*/
	color: #aaa;
	font-size: .875em;
}

.pagination {
	background: #f2f2f2;
	padding: 20px;
	margin-bottom: 20px;
}

.page {
	display: inline-block;
	padding: 0px 9px;
	margin-right: 4px;
	border-radius: 3px;
	border: solid 1px #c0c0c0;
	background: #e9e9e9;
	box-shadow: inset 0px 1px 0px rgba(255,255,255, .8), 0px 1px 3px rgba(0,0,0, .1);
	font-size: .875em;
	font-weight: bold;
	text-decoration: none;
	color: #717171;
	text-shadow: 0px 1px 0px rgba(255,255,255, 1);
}

.page:hover, .page.gradient:hover {
	background: #fefefe;
	background: -webkit-gradient(linear, 0% 0%, 0% 100%, from(#FEFEFE), to(#f0f0f0));
	background: -moz-linear-gradient(0% 0% 270deg,#FEFEFE, #f0f0f0);
}

.page.active {
	border: none;
	background: #616161;
	box-shadow: inset 0px 0px 8px rgba(0,0,0, .5), 0px 1px 0px rgba(255,255,255, .8);
	color: #f0f0f0;
	text-shadow: 0px 0px 3px rgba(0,0,0, .5);
}

.page.gradient {
	background: -webkit-gradient(linear, 0% 0%, 0% 100%, from(#f8f8f8), to(#e9e9e9));
	background: -moz-linear-gradient(0% 0% 270deg,#f8f8f8, #e9e9e9);
}

.pagination.dark {
	background: #414449;
	color: #feffff;
}

.page.dark {
	border: solid 1px #32373b;
	background: #3e4347;
	box-shadow: inset 0px 1px 1px rgba(255,255,255, .1), 0px 1px 3px rgba(0,0,0, .1);
	color: #feffff;
	text-shadow: 0px 1px 0px rgba(0,0,0, .5);
}

.page.dark:hover, .page.dark.gradient:hover {
	background: #3d4f5d;
	background: -webkit-gradient(linear, 0% 0%, 0% 100%, from(#547085), to(#3d4f5d));
	background: -moz-linear-gradient(0% 0% 270deg,#547085, #3d4f5d);
}

.page.dark.active {
	border: none;
	background: #2f3237;
	box-shadow: inset 0px 0px 8px rgba(0,0,0, .5), 0px 1px 0px rgba(255,255,255, .1);
}

.page.dark.gradient {
	background: -webkit-gradient(linear, 0% 0%, 0% 100%, from(#565b5f), to(#3e4347));
	background: -moz-linear-gradient(0% 0% 270deg,#565b5f, #3e4347);
}
</style>
<body>
	
</body>
</html>
<?php 

require_once('connection.php');

$rec_per_page = 5;
$page = '';
$output = '';
if (isset($_GET["page"])) {
	$page = $_GET["page"];

}else
{
	$page = 1;
}

$start_from = ($page - 1) * $rec_per_page;


$sql = "SELECT * FROM tbl_residents ORDER BY id ASC LIMIT $start_from, $rec_per_page";

$res = mysqli_query($con, $sql);
$output .='<table class="responsive-table">
<thead>
<tr>
<th class="center-align">No.</th>
<th class="center-align">Last Name</th>
<th class="center-align">First Name</th>
<th class="center-align">Middle Name</th>
<th class="center-align">Gender</th>
<th class="center-align">Address</th>
<th class="center-align">Occupation</th>
</tr>
</thead>
';

while($row = mysqli_fetch_array($res)){
	$output .= '
	<tr>
	<td class="center-align">'.$row["id"].'</td>
	<td class="center-align">'.$row["r_lname"].'</td>
	<td class="center-align">'.$row["r_fname"].'</td>
	<td class="center-align">'.$row["r_mname"].'</td>
	<td class="center-align">'.$row["r_gender"].'</td>
	<td class="center-align">'.$row["r_address"].'</td>
	<td class="center-align">'.$row["r_occupation"].'</td>
	</tr>

	';
}



$output .='</table><div align="center">';
$page_query = "SELECT * FROM tbl_residents ORDER BY id ASC";
$page_result = mysqli_query($con, $page_query);
$total_records = mysqli_num_rows($page_result);
$total_pages = ceil($total_records/$rec_per_page);


echo "<br><br><br>";

if ($page > 1) {
	$prev_page = $page - 1;
	echo '<a class="page pagination-link" style="cursor:pointer;" id="'. $prev_page .'">Prev</a>';
}

for ($i=1; $i<=$total_pages; $i++) { 
	// $output .='<a class="pagination-link blue btn waves-effect left active" style="cursor:pointer; padding:5px; border:1px solid; color:white;" id="'.$i.'"">'.$i.'</a>';\

	if ($i == $page) {
		echo '<a  class="page dark pagination-link" style="cursor:pointer;" id="'. $i .'">'. $i .'</a>';
	}else{
		echo '<a class="page pagination-link" style="cursor:pointer;" id="'. $i .'">'. $i .'</a>';
	}
}


$next_page = $page + 1;
if ($next_page != $total_pages + 1) {
	echo '<a class="page pagination-link" style="cursor:pointer;" id="'. $next_page .'">Next</a>';
}

// echo $check = $start_from + $rec_per_page;
// if ( $total_records > $check ) {
// 	$next_page = $page + 1;
// 	echo '<a class="page pagination-link" style="cursor:pointer;" id="'. $next_page .'">Next</a>';
// }

$output .='</div>';

echo $output;


?>