<?php 
require 'connection.php';
$query = "SELECT * FROM tbl_official ORDER BY id ASC";
$result = $con->query($query);
$output = '';
while($row = mysqli_fetch_array($result))
{
	$output .= '
	<div class="col s6 m6">
	<div class="card horizontal grey lighten-2 scrollspy">
	<div class="card-image" style="margin-top: 1.5rem !important; margin-left: .2rem !important">
		<img height="150" class="circle" src="data:image/jpeg;base64,'.base64_encode($row['name'] ).'" >
	</div>
	<div class="card-stacked">
	<div class="card-content" style="width:auto; height: 125px; overflow: auto;">
	<h5>'.$row['full_name'].'</h5></span>
	<h6>'.$row['bg_official'].'</h6>
	</div>
	<div class="card-action">
	<span class="card-title activator black-text text-darken-4">'.$row['position'].'</span>
	</div>
	</div>
	</div>
	</div>
	';
}

echo json_encode($output);
?>