$(document).ready(function() {
  fetch_data_project();
  function fetch_data_project()
  {
    var action = "fetch";
    $.ajax({
      url:"http://localhost/bis/include/projectAction.php",
      method:"POST",
      data:{action:action},
      success:function(data)
      {
        $('#image_data_project').html(data);
      }
    });
  }

  $("#form_text").submit(function(e){
    var image_ids = document.getElementById('image_ids').value;
    var titles = document.getElementById('titless').value;
    var captions = document.getElementById('captionss').value;
    e.preventDefault();
    $.ajax({
      url:"http://localhost/bis/include/projectAction.php",
      method:'POST',
      data:{image_ids:image_ids,
        titles:titles,
        captions:captions},
        // dataType:'JSON',

        success:function(data){
          setTimeout(function () {
            Materialize.toast('Updated!', 2000);
            setTimeout(function(){
              $('#update_text').modal('close');
            },1000);
            fetch_data_project();
          },1000);
        }
      });

  });

  $('#add').click(function(){
    $('#image_form')[0].reset();
    $('.modal-title').text("Project Content");
    $('#image_id').val('');
    $('#action').val('insert');
    $('#insert').val("Add Project").removeClass('greenForlife').addClass('blueForlife');;
    $('#ttle').removeClass('hide');
    $('#capsun').removeClass('hide');
    $(".modal").removeClass('center');
    $("#insert").removeClass('green darken-2').addClass('#2196f3 blue');
  });

  $('#image_form').submit(function(event){
    event.preventDefault();
    var image_name = $('#image').val();

    if(image_name == '')
    {
      alert("Please Select Image");
      return false;
    }

    else
    {
      var extension = $('#image').val().split('.').pop().toLowerCase();
      if(jQuery.inArray(extension, ['gif','png','jpg','jpeg']) == -1)
      {
        alert("Invalid Image File");
        $('#image').val('');
        return false;
      }
      else
      {
        $.ajax({
          url:"http://localhost/bis/include/projectAction.php",
          method:"POST",
          data:new FormData(this),
          contentType:false,
          processData:false,
          beforeSend: function(){
            Materialize.toast('Processing....', 1000);
          },
          success:function(data)
          {
           setTimeout(function () {
            Materialize.toast('Done!', 2000);
            $('#image_form')[0].reset();
            $('#addProject').modal('close');
            fetch_data_project();
          },1000);
         }
       });
      }
    }
  });

  $(document).on('click', '.update', function(){
    $('#image_id').val($(this).attr("id"));
    $('#action').val("update");
    $('.modal-title').text("Change Image");
    $('#insert').val("Update").removeClass('blueForlife').addClass('greenForlife');
    $('#addProject').modal("open");
    $('#ttle').addClass('hide');
    $('#capsun').addClass('hide');
    $(".modal").addClass('center');
    $("#paraG").addClass('center');
  });

  $(document).on('click', '.update_text', function(){
    $(".modal").removeClass('center');
    $('.modal-title-update').text("Edit Event");
    $('#update_text').modal("open");
    $('#image_ids').val($(this).attr("id"));


    var image_id = $(this).attr("id");
    $.ajax({
      url:'http://localhost/bis/include/actionOfficial.php',
      method:'POST',
      data:{idP:image_id},
      dataType:'JSON',

      success:function(data) { 
        for (i = 0; i<data.length; i++) {
          document.getElementById('titless').value=data[i].title;
          document.getElementById('captionss').value=data[i].caption;
        }
        $('#update_text').html();
      }

    });
  });

  $(document).on('click', '.delete', function(){
    var image_id = $(this).attr("id");
    var action = "delete";
    if(confirm("Are you sure you want to remove this image from database?"))
    {
      $.ajax({
        url:"http://localhost/bis/include/projectAction.php",
        method:"POST",
        data:{image_id:image_id, action:action},
        success:function(data)
        {
          Materialize.toast('Image Deleted!', 2000);
          fetch_data_project();
        }
      })
    }
    else
    {
      return false;
    }
  });

})