$(document).ready(function () {
  $('#login_form').submit(function (e) {
    var form = $(this).serialize();
     console.log(form);
     e.preventDefault();
     $.ajax({
      url: 'http://localhost/bis/login/login.php',
      method:'POST',
      data: form,
      beforeSend: function () {
        $('#btn_login').html('Logging in...');
      },
      success: function (data) {
        var data_url = data;
        setTimeout(function () {
          if (data) {
            swal("Signing in...", "Successfully Log-in!!", "success");
            setTimeout(function(){
              window.location.href = data_url;
            }, 2000);

          } else {
           $('#login_form')[0].reset();
           swal("Try again!", "Incorrect Username or Password!", "error");
           $('#label1').removeClass('active');
           $('#label2').removeClass('active');
           $('#btn_login').html('Login <i style="font-size: 15px;" class="fa fa-sign-in-alt"></i>');
         }
       },1000);
      }
    });
 });


   // $('#register_form').submit(function () {
  //   var userdata = $(this).serialize();

  //   console.log(userdata);

  //   $.ajax({
  //     url: '',
  //     method: 'POST',
  //     data: userdata,
  //     beforeSend: function () {
  //       $('#register').html('Submitting..');
  //     },
  //     success: function () {
  //       window.location.href = " login.html";
  //     }
  //   })

  //   return false;
  // });
});
