$(document).ready(function(){
	$('select').material_select();
	
	$('.modal').modal();
	 $('.datepicker').pickadate({
    selectMonths: true, // Creates a dropdown to control month
    selectYears: 15 // Creates a dropdown of 15 years to control year
  });
	$('.button-collapse').sideNav({
		menuWidth: 300, // Default is 300
		edge: 'left', // Choose the horizontal origin
		closeOnClick: true, // Closes side-nav on <a> clicks, useful for Angular/Meteor
		draggable: true, // Choose whether you can drag to open on touch screens,
	});

	$('.dropdown-button').dropdown({
		belowOrigin: true,
		constrainWidth: false,
		gutter: 10
	});

	$('#toggleNav').click(function(){
		$('#nav-logo').fadeIn(1000).toggleClass('hide');
		$('#slide-out').toggleClass('fixed');
		$('header').toggleClass('padded');
		$('main').toggleClass('padded');
	});

	// logo animation
	$('#logo').removeClass('scale-out').addClass('scale-in');
	
	// search on the go
	$('#search').keypress( function(e){
		var key = e.which;
		if (key == 13) {
			$('#time-in-result').removeClass('scale-out').addClass('scale-in');
			// throw ajax here
		}
	});
});