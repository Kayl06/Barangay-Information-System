var myUrl = "http://localhost";
var s1 = document.getElementById('ala').innerHTML;
show();
searchResidents();
generate();
$(document).ready(function(){
  // show();
  // showForAdmin();
  document.getElementById("purok").value = s1;
  $('#resident_form').submit(function(e){//Start of Adding of Residents
    var res_form = $(this).serialize();
    e.preventDefault();
    $.ajax({

      url:myUrl + '/bis/include/addresident.php',
      method:'POST',
      data: res_form,
      dataType:'JSON',

      beforeSend: function() {
        Materialize.toast('Processing...', 1000);
      },
      success: function(data) {
        setTimeout(function () {
         Materialize.toast('Resident Successfully Added!', 2000);
         $('#addResident').modal('close');
         $('#resident_form')[0].reset();
         generate();
         show();
       },1000);
      }
    });
  });//end of 'Adding of residentss'


});
function generate(){
  document.getElementById("purok").value = s1;
  $.ajax({
    url: myUrl + '/bis/include/reports.php?report=' + s1, 
    method:'GET',
    data:{report:s1},
    dataType : 'JSON',
    success:function (data){
      var body = "";
      for(var i = 0; i<data.length; i++){
        body += '<tr>';
        body += '<td class="left-align">'+data[i].r_lname+'</td>';
        body += '<td class="left-align">'+data[i].r_fname+'</td>';
        body += '<td class="left-align">'+data[i].r_mname+'</td>';
        body += '<td class="left-align">'+data[i].r_gender+'</td>';
        body += '<td class="left-align">'+data[i].r_address+'</td>';
        body += '<td class="left-align">'+data[i].r_occupation+'</td>';
        body += '<td class="left-align" style="letter-spacing:.2rem;"><a class="accent-5 modal-trigger light" style="color: #3293EE" href="#updateResident" onclick="example('+data[i].id+')"><i style="font-size: 18px;" class="fa fa-pencil-alt"></i></a>  <a href="#!" style="color:#9E0606" onclick="deleteResident('+data[i].id+')"><i style="font-size: 18px;" class="fa fa-trash-alt"></i></a></td>';
        body += '</tr>';
      }
      $('#reportFetch').html(body);
    }
  });
}

function searchResidents() {
  document.getElementById("purok").value = s1;
  var search = $('#search').val();
  if (search !== '') {
    $.ajax({
      url:myUrl + '/bis/include/searchResident.php',
      method:'GET',
      dataType:'JSON',
      data:{search:search},

      success: function(data) {
        var body ="";
        if(data <= 0) {
          body+='<tr>';
          body+='<td></td>';
          body+='<td></td>';
          body+='<td></td>';
          body+='<td class="center-align red-text"><h4>No Result</h4></td>';
          body+='<td></td>';
          body+='<td></td>';
          body+='<td></td>';
          body+='<td></td>';
          body+='</tr>';
          $('#reportFetch').html(body);
        }else{
          for(var i=0; i<data.length; i++){
            body += '<tr>';
            body += '<td class="print left-align hide">'+data[i].id+'</td>';
            body += '<td class="center" id="l">'+data[i].r_lname+'</td>';
            body += '<td class="center">'+data[i].r_fname+'</td>';
            body += '<td class="center">'+data[i].r_mname+'</td>';
            body += '<td class="center">'+data[i].r_gender+'</td>';
            body += '<td class="center">'+data[i].r_address+'</td>';
            body += '<td class="center">'+data[i].r_occupation+'</td>';
            body += '<td class="print center" style="letter-spacing:.2rem;"><a class="accent-5 modal-trigger light" style="color: #3293EE" href="#updateResident" onclick="example('+data[i].id+')"><i style="font-size: 18px;" class="fa fa-pencil-alt"></i></a>  <a href="#!" style="color:#9E0606" onclick="deleteResident('+data[i].id+')"><i style="font-size: 18px;" class="fa fa-trash-alt"></i></a></td>';
            body += '</tr>';
          }
          body += '<tr><td><a class="print btn green" onclick="printReport()" style="padding:1px 15px;"><i class="fa fa-print" style="font-size:16px;"></i></a></td></tr>';
          $('#reportFetch').html(body);
          console.log(data);
        }

      }
    });
  }else {
    generate();
  }
}
function printReport() {
  window.print();
}



 // Start of fetch for managing
 function showForAdmin(){
    // var vUrl="";
    $.ajax({
      url: myUrl + '/bis/include/fetch.php',
      method:'GET',
      dataType:'JSON',

      success: function(data){
        var body = "";
        for(var i = 0; i<data.length; i++){
          body += '<tr>';
          body += '<td class="left-align hide">'+data[i].id+'</td>';
          body += '<td class="center">'+data[i].r_lname+'</td>';
          body += '<td class="center">'+data[i].r_fname+'</td>';
          body += '<td class="center">'+data[i].r_mname+'</td>';
          body += '<td class="center">'+data[i].r_gender+'</td>';
          body += '<td class="center">'+data[i].r_address+'</td>';
          body += '<td class="center">'+data[i].r_occupation+'</td>';
          body += '<td class="center" style="letter-spacing:.2rem;"><a class="accent-5 modal-trigger light" style="color: #3293EE" href="#updateResident" onclick="example('+data[i].id+')"><i style="font-size: 18px;" class="fa fa-pencil-alt"></i></a>  <a href="#!" style="color:#9E0606" onclick="deleteResident('+data[i].id+')"><i style="font-size: 18px;" class="fa fa-trash-alt"></i></a></td>';
         // body += '<td class="center"></td>';
         body += '</tr>';
       }
       $('#reportFetch').html(body);
     }
   });
  }//end of fetch for managing



//Start of Deleting Resident
function deleteResident(id){
  var decision = confirm("Do you want to delete this person?");
  if (decision == true){
    $.ajax({
      url: myUrl + '/bis/include/delete.php',
      method:'POST',
      data:{id:id},

      success: function(data) { 
        Materialize.toast('Resident Successfully Removed',1000);
        generate();
        show();
      }
    });
  }else{
    return false;
  }
}//end of delete resident

//Start of show all in website
function show(page){
  $.ajax({
    url:myUrl + '/bis/include/pagination.php',
    method:'GET',
    data:{page:page},
    // dataType:'JSON',

    success: function(data){
      // var body = "";
      // for(var i = 0; i<data.length; i++){
      //   body += '<tr>';
      //   body += '<td class="center-align">'+data[i].id+'</td>';
      //   body += '<td class="center-align">'+data[i].r_lname+'</td>';
      //   body += '<td class="center-align">'+data[i].r_fname+'</td>';
      //   body += '<td class="center-align">'+data[i].r_mname+'</td>';
      //   body += '<td class="center-align">'+data[i].r_gender+'</td>';
      //   body += '<td class="center-align">'+data[i].r_address+'</td>';
      //   body += '<td class="center-align">'+data[i].r_occupation+'</td>';
      //   body += '</tr>';
      // }
      $('#residentsFetch').html(data);

    }
  });
}// end of show all

$(document).on('click','.pagination-link', function(){
  let page = $(this).attr("id");
  show(page);
});

//Start of show Specific Person In Row
function example(id){
  $.ajax({
    url: myUrl + '/bis/include/fetchForUpdate.php',
    method:'GET',
    data:{id:id},
    dataType:'JSON',

    success: function(data){
      var updateBody = "";
      for (i = 0; i<data.length; i++) {
        document.getElementById('r_id').value=data[i].id;
        document.getElementById('r_lname').value=data[i].r_lname;
        document.getElementById('r_fname').value=data[i].r_fname;
        document.getElementById('r_mname').value=data[i].r_mname;
        document.getElementById('r_gendere').value=data[i].r_gender;
        document.getElementById('r_street').value=data[i].r_street;
        document.getElementById('r_purok').value=data[i].r_purok;
        document.getElementById('r_barangay').value=data[i].r_barangay;
        document.getElementById('r_city').value=data[i].r_city;
        // document.getElementById('r_address').value=data[i].r_address;
        document.getElementById('r_occupation').value=data[i].r_occupation;
      }
      console.log(data);
      $('#updateResident').html();
    }


  });

}//end of show specific person in row

//Start of Updating Residents
$("#updateResident").submit(function(e){
  var r_id = document.getElementById('r_id').value;
  var r_lname = document.getElementById('r_lname').value;
  var r_fname = document.getElementById('r_fname').value;
  var r_mname = document.getElementById('r_mname').value;
  var r_gender = document.getElementById('r_gendere').value;
  var r_street= document.getElementById('r_street').value;
  var r_purok =document.getElementById('r_purok').value;
  var r_barangay =document.getElementById('r_barangay').value;
  var r_city =document.getElementById('r_city').value;
  // var r_address = document.getElementById('r_address').value;
  var r_occupation = document.getElementById('r_occupation').value;

  e.preventDefault();
  $.ajax({
    url:myUrl + '/bis/include/fetchForUpdate.php',
    method:'POST',
    data:{r_id:r_id,
      r_lname:r_lname,
      r_fname:r_fname,
      r_mname:r_mname,
      r_gender:r_gender,
      r_street:r_street,
      r_purok:r_purok,
      r_barangay:r_barangay,
      r_city:r_city,
      // r_address:r_address,
      r_occupation:r_occupation
    },
    dataType:'JSON',

    beforeSend: function() {
      Materialize.toast('Processing..', 1000);
    },

    success:function(data){
      console.log(data);
      setTimeout(function () {
        Materialize.toast('Updated!', 2000);
        setTimeout(function(){
          $('#updateResident').modal('close');
        },1000);
        generate();
        show();
      },1000);
    }
  });


});//end




