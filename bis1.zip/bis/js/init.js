$(document).ready(function() {
	$('.scrollspy').scrollSpy();
	$('.carousel.carousel-slider').carousel({fullWidth: true});
	// $('.datepicker').pickadate({
	// 	selectMonths: true,
	// 	selectYears: 15 
	// });
	// $('.datepicker').pickadate({
 //    selectMonths: true, // Creates a dropdown to control month
 //    selectYears: 15, // Creates a dropdown of 15 years to control year
 //    format: 'dd-mm-yyyy' });

// Initialize collapse button
$(".button-collapse").sideNav();
// Initialize collapsible (uncomment the line below if you use the dropdown variation)
//$('.collapsible').collapsible();

$('.tooltipped').tooltip({delay: 300});

$('.parallax').parallax();

$('#hello').fadeIn(500);

$('#hello').fadeOut(5000);

$(window).scroll(function() {
	var scrollPos = $(window).scrollTop();

	if (scrollPos >= 400) {
		$('nav.main-nav').removeClass('white z-depth-0').addClass('white z-depth-43 fixed-nav');
	}else {
		$('nav.main-nav').removeClass('white z-depth-0').addClass('white z-depth-0 fixed-nav');
	}
});
});

