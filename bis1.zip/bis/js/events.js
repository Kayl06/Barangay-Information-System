$(document).ready(function(){
  fetch_data();
  function fetch_data()
  {
    var action = "fetch";
    $.ajax({
      url:"http://localhost/bis/include/action.php",
      method:"POST",
      data:{action:action},
      success:function(data)
      {
        $('#image_data').html(data);
      }
    });
  }

  $('#add').click(function(){
    $('#image_form')[0].reset();
    $('.modal-title').text("Event Content");
    $('#image_id').val('');
    $('#action').val('insert');
    $('#insert').val("Add Event").removeClass('greenForlife').addClass('blueForlife');;
    $('#ttle').removeClass('hide');
    $('#capsun').removeClass('hide');
    $(".modal").removeClass('center');
    $("#insert").removeClass('green darken-2').addClass('#2196f3 blue');
  });

  $('#image_form').submit(function(event){
    event.preventDefault();
    var image_name = $('#image').val();

    if(image_name == '')
    {
      alert("Please Select Image");
      return false;
    }

    else
    {
      var extension = $('#image').val().split('.').pop().toLowerCase();
      if(jQuery.inArray(extension, ['gif','png','jpg','jpeg']) == -1)
      {
        alert("Invalid Image File");
        $('#image').val('');
        return false;
      }
      else
      {
        $.ajax({
          url:"http://localhost/bis/include/action.php",
          method:"POST",
          data:new FormData(this),
          contentType:false,
          processData:false,
          beforeSend: function(){
            Materialize.toast('Processing....', 1000);
          },
          success:function(data)
          {
           setTimeout(function () {
            Materialize.toast('Done!', 2000);
            $('#image_form')[0].reset();
            $('#addPic').modal('close');
            fetch_data();
          },1000);
         }
       });
      }
    }
  });

  $(document).on('click', '.blueForlife', function(){
    var caption = $('#caption').val();
    var title = $('#title').val();
    if(caption == '' || title ==''){
      // alert('Required Field/s');
      Materialize.toast('Required Field/s', 1000);
    }
  });


  $(document).on('click', '.delete', function(){
    var image_id = $(this).attr("id");
    var action = "delete";
    if(confirm("Are you sure you want to remove this image from database?"))
    {
      $.ajax({
        url:"http://localhost/bis/include/action.php",
        method:"POST",
        data:{image_id:image_id, action:action},
        success:function(data)
        {
          Materialize.toast('Image Deleted!', 2000);
          fetch_data();
        }
      })
    }
    else
    {
      return false;
    }
  });

  $(document).on('click', '.update', function(){
    $('#image_id').val($(this).attr("id"));
    $('#action').val("update");
    $('.modal-title').text("Change Image");
    $('#insert').val("Update").removeClass('blueForlife').addClass('greenForlife');
    $('#addPic').modal("open");
    $('#ttle').addClass('hide');
    $('#capsun').addClass('hide');
    $(".modal").addClass('center');
    $("#paraG").addClass('center');
  });

  $(document).on('click', '.update_text', function(){
    $(".modal").removeClass('center');
    $('.modal-title-update').text("Edit Event");
    $('#update_text').modal("open");
    $('#image_ids').val($(this).attr("id"));


    var image_id = $(this).attr("id");
    $.ajax({
      url:'http://localhost/bis/include/actionOfficial.php',
      method:'POST',
      data:{id:image_id},
      dataType:'JSON',

      success:function(data) { 
        for (i = 0; i<data.length; i++) {
          document.getElementById('titles').value=data[i].title;
          document.getElementById('captions').value=data[i].caption;
        }
        $('#update_text').html();
      }

    });
  });

  $("#image_form_text").submit(function(e){
    var image_ids = document.getElementById('image_ids').value;
    var titles = document.getElementById('titles').value;
    var captions = document.getElementById('captions').value;
    e.preventDefault();
    $.ajax({
      url:'http://localhost/bis/include/action.php',
      method:'POST',
      data:{image_ids:image_ids,
        titles:titles,
        captions:captions},
        dataType:'JSON',

        success:function(data){
         setTimeout(function () {
          Materialize.toast('Updated!', 2000);
          setTimeout(function(){
            $('#update_text').modal('close');
          },1000);
          fetch_data();
        },1000);
       }
     });

  });

  
});