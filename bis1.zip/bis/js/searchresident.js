searchResident1();
function searchResident1() {
	var search = $('#search1').val();
	if (search !== '') {
		$.ajax({
			url:'http://localhost/bis/include/searchResident.php',
			method:'GET',
			dataType:'JSON',
			data:{search:search},

			success: function(data) {
				var body ="";
				if(data <= 0) {
					body+='<tr>';
					body+='<td></td>';
					body+='<td></td>';
					body+='<td></td>';
					body+='<td class="center-align red-text"><h4>No Result</h4></td>';
					body+='<td></td>';
					body+='<td></td>';
					body+='<td></td>';
					body+='<td></td>';
					body+='</tr>';
					$('#residentsFetch').html(body);
				}else{
					body +='<table class="responsive-table">';
					body +='<thead>';
					body +='<tr>';
					body +='<th class="center-align">No.</th>';
					body +='<th class="center-align">Last Name</th>';
					body +='<th class="center-align">First Name</th>';
					body +='<th class="center-align">Middle Name</th>';
					body +='<th class="center-align">Gender</th>';
					body +='<th class="center-align">Address</th>';
					body +='<th class="center-align">Occupation</th>';
					body +='</tr>';
					body += '</thead>'
					for(var i=0; i<data.length; i++){
						body += '<tr>';
						body += '<td class="center-align">'+data[i].id+'</td>';
						body += '<td class="center-align">'+data[i].r_lname+'</td>';
						body += '<td class="center-align">'+data[i].r_fname+'</td>';
						body += '<td class="center-align">'+data[i].r_mname+'</td>';
						body += '<td class="center-align">'+data[i].r_gender+'</td>';
						body += '<td class="center-align">'+data[i].r_address+'</td>';
						body += '<td class="center-align">'+data[i].r_occupation+'</td>';
						body += '</tr>';
					}
					body += '</table>';
					$('#residentsFetch').html(body);
				}

			}
		});
	}else {
		show();
	}
}
