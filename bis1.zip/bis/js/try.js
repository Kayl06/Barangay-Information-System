var myUrl = "http://localhost";
fetch_official();
$(document).ready(function(){
  showOfficial();
  projectFetch();
  eventsFetch();

  function projectFetch() {
    $.getJSON(myUrl+'/bis/include/projectFetch.php', function(data){
      $('#projectsFetch').html(data);
    });
  }

  function eventsFetch()
  {
    $.getJSON(myUrl+"/bis/include/eventsFetch.php",function(data){
      $('#eventsFetch').html(data);
    });
  }

  function showOfficial()
  {
    $.getJSON(myUrl+"/bis/include/officialFetch.php", function(data){
      $('#officials').html(data);
    });
  }


  $('#official_form').submit(function(event){
    $('#image_id').val('');
    $('#action').val('insert');
    event.preventDefault();
    var image_name = $('#image').val();
    if(image_name == '')
    {
      alert("Please Select Image");
      return false;
    }
    else
    {
      var extension = $('#image').val().split('.').pop().toLowerCase();
      if(jQuery.inArray(extension, ['gif','png','jpg','jpeg']) == -1)
      {
        alert("Invalid Image File");
        $('#image').val('');
        return false;
      }
      else
      {
      var position = document.getElementById('position').value;
      
        if (position == '') {
          alert('You forgot to insert Position');

        }else{

          $.ajax({  
            url:myUrl + "/bis/include/insertOfficial.php",
            method:"POST",
            data:new FormData(this),
            contentType:false,
            processData:false,
            beforeSend: function(){
              Materialize.toast('Processing....', 1000);
            },
            success:function(data)
            {
              console.log(data);
              setTimeout(function(){
                Materialize.toast('Done!', 2000);
              },2000);
              setTimeout(function () {
                $('#official_form')[0].reset();
                // window.location.href ='http://localhost/bis/official.php';
              },3500);


            }
          });
        }
      }
    }
  });

  $(document).on('click', '.update_text', function(){
    $('#update_text').modal("open");
    $('#image_ids').val($(this).attr("id"));


    var image_id = $(this).attr("id");
    $.ajax({
      url:myUrl+'/bis/include/actionOfficial.php',
      method:'POST',
      data:{ids:image_id},
      dataType:'JSON',

      success:function(data) { 
        for (i = 0; i<data.length; i++) {
          document.getElementById('f_name').value=data[i].full_name;
          document.getElementById('pusit').value=data[i].position;
          document.getElementById('b_ground').value=data[i].bg_official;
        }
        $('#update_text').html();
      }
    });

  });


  $("#image_form_text").submit(function(e){
    var image_ids = document.getElementById('image_ids').value;
    var f_name = document.getElementById('f_name').value;
    var pusit = document.getElementById('pusit').value;
    var b_ground = document.getElementById('b_ground').value;
    e.preventDefault();
    if (pusit !== "Brgy.Captain" && pusit !== "Brgy.Kapitan" && pusit !== "Brgy.Kagawad" && pusit !== "Brgy.Kgwd") {
      Materialize.toast('Invalid Input! <br>Maybe try "Brgy.Kapitan or Brgy.Kagawad"', 5000, 'orange-text');
    }
    else{
      $.ajax({
        url:myUrl+'/bis/include/actionOfficial.php',
        method:'POST',
        data:{image_ids:image_ids,
          f_name:f_name,
          pusit:pusit,
          b_ground:b_ground
        },
        dataType:'JSON',

        success:function(data){
          console.log(data);
          setTimeout(function () {
            Materialize.toast('Successfully Update!', 2000);
            setTimeout(function(){
              $('#update_text').modal('close');
            },1000);
            fetch_official();
          },1000);
        }
      });
    }
  });

  $(document).on('click', '.delete', function(){
    var image_id = $(this).attr("id");
  // var action = "delete";
  if(confirm("Are you sure you want to remove this image from database?"))
  {
    $.ajax({
      url:"http://localhost/bis/include/actionOfficial.php",
      method:"POST",
      data:{image_id:image_id},
      success:function(data)
      {
        Materialize.toast('Image Deleted!', 2000);
        fetch_official();
      }
    })
  }
  else
  {
    return false;
  }
});
});

function fetch_official()
{
  var action = "fetch";
  $.post('http://localhost/bis/include/insertOfficial.php', { action: action }, function(data) {
    $('#image_official').html(data);
  });
}
$(document).on('click', '.update_pic', function(){
  $('#image_idX').val($(this).attr("id"));
  $('#update_image').modal("open");
  $('#action').val("update");
}); 

$("#image_update_form").submit(function(e){
  e.preventDefault();
  var image_name = $('#imageX').val();
  if(image_name == '')
  {
    alert("Please Select Image");
    return false;
  }
  else
  {
    var extension = $('#imageX').val().split('.').pop().toLowerCase();
    if(jQuery.inArray(extension, ['gif','png','jpg','jpeg']) == -1)
    {
      alert("Invalid Image File");
      $('#imageX').val('');
      return false;
    }
    else
    {
      $.ajax({
        url:myUrl+"/bis/include/insertOfficial.php",
        method:"POST",
        data:new FormData(this),
        contentType:false,
        processData:false,
        beforeSend: function(){
          Materialize.toast('Processing....', 1000);
        },
        success:function(data)
        {
          setTimeout(function () {
            Materialize.toast('Done!', 2000);
            $('#update_image').modal('close');
            fetch_official();
          },1000);
        }
      });
    }
  }
});
