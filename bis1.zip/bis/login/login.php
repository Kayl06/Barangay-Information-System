<?php
include '../include/connection.php';

session_start();

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "SELECT * FROM accounts WHERE username = '$username' AND password = '$password'";
$login = $con->query($sql);

$login->fetch_all(MYSQLI_ASSOC);

$row_count = $login->num_rows;

if($row_count != 0){
	foreach($login as $row){
		$ID = $row['id'];
		$username = $row['username'];
		$password = $row['password'];
		$firstname = $row['firstname'];
		$accountType = $row['position'];
		$assigned = $row['assigned'];
	}

	if( $username == $username && $password == $password ){
		if ($accountType !== "Purok Leader") {
			# code...
			$_SESSION['id'] = $ID;
			$_SESSION['username'] = $username;
			$_SESSION['firstname'] = $firstname;
			$_SESSION['position'] = $accountType;
			$_SESSION['assigned'] = $assigned;
			echo '';

			echo 'adminpage.php';
		}
		else{
			$_SESSION['id'] = $ID;
			$_SESSION['username'] = $username;
			$_SESSION['firstname'] = $firstname;
			$_SESSION['position'] = $accountType;
			$_SESSION['assigned'] = $assigned;
			echo '';

			echo 'purokpage.php';
		}

	}


}
?>