<?php
include('include/connection.php');
session_start();

$user_check = $_SESSION['username'];

$ses_sql = mysqli_query($con,"SELECT username from accounts where username = '$user_check' ");

$row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);

$login_session = $row['username'];

if(!isset($_SESSION['username'])){
	header("location:loginform.html");
}	
?>