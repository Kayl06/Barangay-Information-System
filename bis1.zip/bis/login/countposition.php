<?php 
header('Allow-Access-Origin:*');
header('Content-Type:application-json');
?>

<?php 
session_start();

include '../include/connection.php';

$sql1 = "SELECT COUNT(position) as total_position FROM accounts WHERE position = 'Purok Leader'";
$res = $con->query($sql1);

$count = array();
while ($rows = mysqli_fetch_assoc($res)) {
	// array_push($count, $data);
	$count = $rows['total_position'];

}
$_SESSION['total_position'] = $count;
echo json_encode($count);

?>