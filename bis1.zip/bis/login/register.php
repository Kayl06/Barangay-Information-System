<?php 
header('Allow-Access-Origin:*');
header('Content-Type:application-json');
?>
<?php 
session_start();

require_once('../include/connection.php');


$uname = $_GET['username'];
$pword = $_GET['password'];
$fname = $_GET['first_name'];
$lname = $_GET['last_name'];
$email = $_GET['email'];
$puroks = $_GET['purokS'];

$accountType = $_GET['accountType'];

if ($accountType == "Admin") {
	$accountType = "Admin";
	$sql = "INSERT INTO accounts (username, password, firstname, lastname, email, position, assigned) 
	VALUES ('$uname', '$pword','$fname','$lname', '$email','$accountType', 'Brgy.Staff')";

	$con->query($sql);
	echo json_encode(array('response' => 'successfully inserted'));
}else {
	$accountType = "Purok Leader";
	$sql = "INSERT INTO accounts (username, password, firstname, lastname, email, position, assigned) 
	VALUES ('$uname', '$pword','$fname','$lname', '$email','$accountType', '$puroks')";

	$con->query($sql);
	echo json_encode(array('response' => 'successfully inserted'));
}




?>