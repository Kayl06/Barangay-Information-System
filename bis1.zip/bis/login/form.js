$(document).ready(function () {
    $('#login_form').submit(function (e) {
        var form = $(this).serialize();
        e.preventDefault();
        $.ajax({
            url: 'http://localhost/bis/login/login.php',
            method: 'POST',
            data: form,
            beforeSend: function () {
                $('#btn_login').html('Logging in..');
            },
            success: function (data) {
                var data_url = data;
                setTimeout(function () {
                    if (data) {
                        window.location.href = data_url;
                    } else {
                        $('#notice').html('Invalid Username or Password');
                        $('#login_form')[0].reset();
                        $('#btn_login').html('Login');
                    }
                }, 500);
            }
        })
    });

    // $('#register_form').submit(function () {
    //     var userdata = $(this).serialize();

    //     console.log(userdata);

    //     $.ajax({
    //         url: 'http://localhost/grocery/php/register.php',
    //         method: 'POST',
    //         data: userdata,
    //         beforeSend: function () {
    //             $('#register').html('Submitting..');
    //         },
    //         success: function () {
    //             window.location.href = " login.html";
    //         }
    //     })

    //     return false;
    // });
});