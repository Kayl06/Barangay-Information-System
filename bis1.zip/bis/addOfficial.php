<?php 
include 'content/head.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Manage Officials</title>
</head>
<body class="grey lighten-2">
	<?php include 'sidenav.php';
	include 'calendar.php'; ?>
	<!-- <div class="center" style="font-size: 20px;"><a href="official.php"> -->
		<!-- <i class="fas fa-arrow-alt-circle-left"></i> Go back</a> -->
		<!-- </div> -->
		<main>		
			<div class="row">
				<div class="col s12">
					<form id="official_form" method="post" enctype="multipart/form-data">
						<div class="row">
							<p><label>Select Image</label>
								<input type="file" name="image" id="image" />
							</p>
							<input type="hidden" name="action" id="action" value="insert" />
							<input type="hidden" name="image_id" id="image_id" />
							<div class="input-field col s6">
								<input required="" id="fname" name="fname" type="text">
								<label for="fname">First Name</label>
							</div>
							<div class="input-field col s6">
								<input required id="mname" name="mname" type="text">
								<label for="mname">Middle Initial</label>
							</div>
						</div>
						<div class="row">
							<div class="input-field col s6">
								<input required="" id="lname" name="lname" type="text">
								<label for="lname">Last Name</label>
							</div>
							<div class="input-field col s6">
								<select name="position" id="position" onclick="click2()">
									<option value="" disabled selected>Position</option>
									<option value="Brgy.Captain"  id="cptain" name="">Brgy.Captain</option>
									<option value="Brgy.Kagawad" name="">Brgy.Kagawad</option>
								</select>	
							</div>				
						</div>
						<div class="row">
							<div class="input-field col s6">
								<textarea required id="bground" name="bground" class="materialize-textarea"></textarea>
								<label for="bground">Background of Official</label>
							</div>
							<div class="input-field col s6">
								<input style="margin-top: 10%;" type="submit" name="insert" id="insert" value="Submit" class="btn blueForlife">
							</div>
						</div>
					</form>
				</div>
			</div>
		</main>
		<script src="js/jquery-3.2.1.min.js"></script>
		<script src="js/materialize.min.js"></script>
		<script src="js/init.js"></script>
		<script src="js/initial.js"></script>
		<script src="js/time.js"></script>
		<script src="js/try.js"></script>
		<script>
			function click2() {
				$('#cptain').attr("disabled selected"); 
}
</script>
<script src="js/sweetalert.min.js"></script>

</body>
</html>