<!DOCTYPE html>
<html lang="en">
<head>
	<title>Purok Page</title>
	<?php include 'content/head.php'; ?>
	<link rel="stylesheet" href="css/print.css" media="print">
</head>
<style>
.tble {
	font-size: 13.5px; margin-left: -14px !important;
	height: 170px !important; overflow: auto !important;
}
</style>
<body class="#bdbdbd grey lighten-2" id="page-reports">
	<main>
		
		<div class="yes-print row" style="position: relative;">
			<hr>
			<div class="col s2 offset-s2">
				<img src="images/NEWCABALAN.png" width="100" height="100" style="position: absolute; top: 20px; left: 150px; margin-top: 2.5vh !important;">
			</div>
			<div class="col s6" id="p1">
				<h3 style="text-align: center; font-family: century gothic;">Brgy. New Cabalan</h3>
				<h5 style="text-align: center; font-family: century gothic;"> Olongapo City </h5>
				<p style="text-align: center; font-size: 13px;"><br>Tel No.(047) 224-2089/6969 Fax No. (047) 224-2089<br></p>
			</div>
		</div>

		<div class="row">
			<div class="print">
				<a class="btn green" style="padding:1px 15px;"><i class="fa fa-print" style="font-size:16px;"></i></a>
			</div>
			<br>
			<div class="row" id="reports-header">
				<span class="print white-text hide" id="ala"><?php echo $_SESSION['assigned'];?></span>
				<table class="tble col s12 responsive-table z-depth-1" id="report">
					<thead class="white">
						<tr>
							<th class="center-align">Last Name</th>
							<th class="center-align">First Name</th>
							<th class="center-align">Middle Name</th>
							<th class="center-align">Gender</th>
							<th class="center-align">Address</th>
							<th class="center-align">Occupation</th>
							<th class="print center-align">Action</th>
						</tr>
					</thead>
					<tbody id="reportFetch" class="white"></tbody>
				</table>
				
			</div>
		</div>
	</main>
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/materialize.min.js"></script>
	<script src="js/init.js"></script>
	<script src="js/initial.js"></script>
	<script src="js/time.js"></script>
	<script src="js/form.js"></script>
	<script src="js/purokAdd.js"></script>
	<script src="js/sweetalert.min.js"></script>
	<script>
			//var myUrl = "http://localhost";

		</script>
	</body>
	</html>